package com.sevattal.springcloud.controller;

import com.sevattal.springcloud.entities.CommonResult;
import com.sevattal.springcloud.entities.Payment;
import com.sevattal.springcloud.lb.LoadBalancer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.net.URI;
import java.util.List;

@RestController
@Slf4j
public class OrderController {

    /*
    * Eureka 中注册的微服务名称
    * */
    public static final String PAYMENT_URL = "http://CLOUD-PROVIDER-SERVICE";
    /*
    * @resource是基于j2ee的注解，默认是按名字进行注解，若不指定装配bean的名字，
    * 当注解写在字段上时，默认取字段名，按照名称查找通过set方法进行装配，
    * 倘若有多个子类，则会报错。若想不报错，只需加（required=false）
    *
    * @autowired是基于spring的注解org.springframework.beans.factory.annotation.Autowired,
    * 它默认是按类型进行的装配的，如果想要它按名字进行装配只需在@autowired
    * 下面加@qualifier("name")`注解
    *
    * */
    /*
    * RestTemplate 是 Spring 给出的一个http的客户端的包
    *
    * */
    @Resource
    private RestTemplate restTemplate;

    @Resource
    private LoadBalancer loadBalancer;

    @Resource
    private DiscoveryClient discoveryClient;

    @GetMapping("/consumer/payment/create")
    public CommonResult<Payment> create(Payment payment){

        return restTemplate.postForObject(PAYMENT_URL+ "/payment/create", payment, CommonResult.class);
    }

    @GetMapping("/consumer/payment/get/{id}")
    public CommonResult<Payment> getPayment(@PathVariable("id") Long id){

        return restTemplate.getForObject(PAYMENT_URL+ "/payment/get/" + id, CommonResult.class);
    }

    @GetMapping("/consumer/payment/getForEntity/{id}")
    public CommonResult<Payment> getPayment2(@PathVariable("id") Long id) {
        ResponseEntity<CommonResult> entity = restTemplate.getForEntity(PAYMENT_URL+ "/payment/get/"+id, CommonResult.class);
        if (entity.getStatusCode().is2xxSuccessful()){
            return entity.getBody();
        }else {
            return new CommonResult<>(444,"操作失败");
        }
    }

    @GetMapping("/consumer/payment/lb")
    public String getPaymentLB() {
        List<ServiceInstance> instances = discoveryClient.getInstances("CLOUD-PROVIDER-SERVICE");
        if (instances == null || instances.size() <= 0){
            return  null;
        }else {
            ServiceInstance serviceInstance = loadBalancer.instances(instances);
            URI uri = serviceInstance.getUri();
            return  restTemplate.getForObject(uri +"/payment/lb", String.class);
        }
    }


}
