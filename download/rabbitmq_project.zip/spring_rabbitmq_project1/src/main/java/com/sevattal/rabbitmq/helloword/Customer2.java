package com.sevattal.rabbitmq.helloword;

import com.rabbitmq.client.*;
import com.sevattal.rabbitmq.util.RabbitMQUtils;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class Customer2 {

    @Test
    public void test() throws IOException, TimeoutException {
        Connection connection = RabbitMQUtils.getConnection();
        Channel channel = connection.createChannel();
        channel.queueDeclare("hello", true, false, false, null);
        /*
         * 消费消息
         * 参数1：消费队列名称
         * 参数2：开启消息的自动确认机制
         * 参数3：消费消息时回调接口
         * */
        channel.basicConsume("hello", true, new DefaultConsumer(channel) {
            /*
             * 最后一个参数：消息队列中取出的消息
             * */
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                System.out.println(new String(body));
            }
        });
        RabbitMQUtils.closeConnectionAndChanel(channel,connection);
    }

}
