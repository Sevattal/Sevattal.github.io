package com.sevattal.rabbitmq.helloword;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.sevattal.rabbitmq.util.RabbitMQUtils;
import org.junit.jupiter.api.Test;

import java.io.IOException;

public class Provider2 {

    /*
    *
    * 使用工具类管理 连接和通道
    * */
    @Test
    public void testSendMessage() throws IOException {
        Connection connection = RabbitMQUtils.getConnection();

        Channel channel = connection.createChannel();
        channel.queueDeclare("hello",true,false,false,null);
        channel.basicPublish("","hello", null,"hello rabbitmq".getBytes());

        RabbitMQUtils.closeConnectionAndChanel(channel,connection);
    }

}
