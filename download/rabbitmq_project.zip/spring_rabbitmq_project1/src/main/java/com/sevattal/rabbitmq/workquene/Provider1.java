package com.sevattal.rabbitmq.workquene;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.sevattal.rabbitmq.util.RabbitMQUtils;
import org.junit.jupiter.api.Test;

import java.io.IOException;

public class Provider1 {
    /*
     *
     * 使用工具类管理 连接和通道
     * */
    @Test
    public void testSendMessage() throws IOException {
        Connection connection = RabbitMQUtils.getConnection();
        Channel channel = connection.createChannel();
        channel.queueDeclare("work",true,false,false,null);
        for (int i =0 ; i<20;i++) {
            channel.basicPublish("", "work", null, (i +"hello work rabbitmq").getBytes());
        }
        RabbitMQUtils.closeConnectionAndChanel(channel,connection);
    }

}
