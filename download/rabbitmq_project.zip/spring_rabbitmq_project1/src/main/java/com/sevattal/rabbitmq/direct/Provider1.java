package com.sevattal.rabbitmq.direct;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.sevattal.rabbitmq.util.RabbitMQUtils;
import org.junit.jupiter.api.Test;

import java.io.IOException;

public class Provider1 {
    /*
     *
     * 使用工具类管理 连接和通道
     * */
    @Test
    public void testSendMessage() throws IOException {
        Connection connection = RabbitMQUtils.getConnection();
        Channel channel = connection.createChannel();
        // 通过通道声明交换机，参数1：交换机名称 参数2：direct 路由模式
        channel.exchangeDeclare("logs_direct","direct");//广播 一条消息多个消费者同时消费
        // 定义路由key
        String routingkey = "error";
        // 发送消息
        channel.basicPublish("logs_direct", routingkey, null, ("direct模型发布的基于 route key: "+ routingkey).getBytes());
        RabbitMQUtils.closeConnectionAndChanel(channel,connection);
    }

}
