package com.sevattal.rabbitmq.helloword;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.MessageProperties;
import org.junit.jupiter.api.Test;


import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class Provider1 {

    @Test
   public void  test1() throws IOException, TimeoutException {
        //创建连接工厂
        ConnectionFactory connectionFactory = new ConnectionFactory();
        connectionFactory.setHost("192.168.10.11");
        connectionFactory.setPort(5672);
        connectionFactory.setUsername("sevattal");
        connectionFactory.setPassword("123456");
        connectionFactory.setVirtualHost("/elasticsearch");
        Connection connection = connectionFactory.newConnection();
        //创建通道
        Channel channel = connection.createChannel();
        /*
        * 通道绑定对应消息队列
        * 参数1：队列名称 如果队列不存在自动创建
        * 参数2：用来定义队列特性是否要持久化
        * 参数3：是否独占队列，也就是说只允许当前的连接能够使用该队列
        * 参数4：是否在消费完成后自动删除队列
        * 参数5：额外附加参数
        * */
        channel.queueDeclare("hello",true,false,false,null);
        /*
        * 通道发布消息
        * 参数1：交换机
        * 参数2：队列的名称
        * 参数3：传递消息的额外设置
        * 参数4：消息的具体内容
        * */
        channel.basicPublish("","hello", MessageProperties.PERSISTENT_TEXT_PLAIN,"hello rabbitmq".getBytes());
        channel.close();
        connection.close();
    }
}
