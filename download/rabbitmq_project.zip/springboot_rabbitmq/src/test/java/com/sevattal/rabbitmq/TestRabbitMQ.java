package com.sevattal.rabbitmq;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@SpringBootTest(classes = RabbitmqSpringApplication.class)
@RunWith(SpringRunner.class)
public class TestRabbitMQ {

    // 注入rabbitTemplate
    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Test
    public void testTopic(){
        rabbitTemplate.convertAndSend("topics","user.save.findAll","user.save.findAll 的消息");
    }

    @Test
    public void testDirect(){
        rabbitTemplate.convertAndSend("directs","error","error 的日志信息");
    }

    // 广播
    @Test
    public void testFanout() {
        rabbitTemplate.convertAndSend("logs","","这是日志广播");
    }

    @Test
    public void testHelloWord(){
        rabbitTemplate.convertAndSend("hello","hello world");
    }

    @Test
    public void testWork(){
        for (int i = 0; i < 10; i++) {
            rabbitTemplate.convertAndSend("work","hello work!");
        }
    }
}
