package com.sevattal.rabbitmq.hello;

import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
@RabbitListener(queuesToDeclare = @Queue("hello"))
public class HelloCustomer {

    /*
    * 处理队列中的回调方法
    * */
    @RabbitHandler
    public void receive1(String message) {
        System.out.println("message = " + message);
    }
}
