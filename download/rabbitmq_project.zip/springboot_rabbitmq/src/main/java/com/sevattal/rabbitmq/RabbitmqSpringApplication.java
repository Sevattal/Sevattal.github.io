package com.sevattal.rabbitmq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabbitmqSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(RabbitmqSpringApplication.class);
    }
}
