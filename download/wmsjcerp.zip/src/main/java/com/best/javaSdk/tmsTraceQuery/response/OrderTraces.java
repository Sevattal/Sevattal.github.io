package com.best.javaSdk.tmsTraceQuery.response;

import java.util.List;


public class OrderTraces {
	private List<OrderTrace> orderTrace;

    public List<OrderTrace>  getOrderTrace()
    {
        return this.orderTrace;
    }

    public void setOrderTrace(List<OrderTrace>  value)
    {
        this.orderTrace = value;
    }

}
