package com.best.javaSdk.getShippingOrderInfo.response;



public class TrackingInfo {
	private String status;
	private String timePoint;
	private String courier;
	private String courierPhone;
	private String description;

    public String getStatus()
    {
        return this.status;
    }

    public void setStatus(String value)
    {
        this.status = value;
    }

    public String getTimePoint()
    {
        return this.timePoint;
    }

    public void setTimePoint(String value)
    {
        this.timePoint = value;
    }

    public String getCourier()
    {
        return this.courier;
    }

    public void setCourier(String value)
    {
        this.courier = value;
    }

    public String getCourierPhone()
    {
        return this.courierPhone;
    }

    public void setCourierPhone(String value)
    {
        this.courierPhone = value;
    }

    public String getDescription()
    {
        return this.description;
    }

    public void setDescription(String value)
    {
        this.description = value;
    }


}
