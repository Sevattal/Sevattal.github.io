package com.best.javaSdk.converter.util.jsonReader;

public class JSONValidatingWriter extends com.best.javaSdk.converter.util.jsonReader.JSONWriter {

    private com.best.javaSdk.converter.util.jsonReader.JSONValidator validator;
    
    public JSONValidatingWriter(com.best.javaSdk.converter.util.jsonReader.JSONValidator validator, boolean emitClassName) {
        super(emitClassName);
        this.validator = validator;
    }
    
    public JSONValidatingWriter(com.best.javaSdk.converter.util.jsonReader.JSONValidator validator) {
        this.validator = validator;
    }
    
    public JSONValidatingWriter(com.best.javaSdk.converter.util.jsonReader.JSONErrorListener listener, boolean emitClassName) {
        this(new com.best.javaSdk.converter.util.jsonReader.JSONValidator(listener), emitClassName);
    }
    
    public JSONValidatingWriter(com.best.javaSdk.converter.util.jsonReader.JSONErrorListener listener) {
        this(new com.best.javaSdk.converter.util.jsonReader.JSONValidator(listener));
    }
    
    public JSONValidatingWriter() {
        this(new com.best.javaSdk.converter.util.jsonReader.StdoutStreamErrorListener());
    }
    
    public JSONValidatingWriter(boolean emitClassName) {
        this(new com.best.javaSdk.converter.util.jsonReader.StdoutStreamErrorListener(), emitClassName);
    }
    
    private String validate(String text) {
        validator.validate(text);
        return text;
    }

    public String write(Object object) {
        return validate(super.write(object));
    }

    public String write(long n) {
        return validate(super.write(n));
    }

    public String write(double d) {
        return validate(super.write(d));
    }

    public String write(char c) {
        return validate(super.write(c));
    }

    public String write(boolean b) {
        return validate(super.write(b));
    }
}
