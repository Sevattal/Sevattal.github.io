package com.best.javaSdk.wmsSkuNotify.request;

import com.best.javaSdk.BaseRequest;
import com.best.javaSdk.BaseResponse;
import com.best.javaSdk.Parser;


public class WmsSkuNotifyReq implements BaseRequest {
	private String providerCode;
	private Products products;

    public String getProviderCode()
    {
        return this.providerCode;
    }

    public void setProviderCode(String value)
    {
        this.providerCode = value;
    }

    public Products getProducts()
    {
        return this.products;
    }

    public void setProducts(Products value)
    {
        this.products = value;
    }

    public String obtainServiceType() {
        return "WMS_SKU_NOTIFY";
    }

    public BaseResponse makeResponse(String rsp, String format) {
        if ("xml".equalsIgnoreCase(format)) {
			return Parser.coverXml2Object(rsp, com.best.javaSdk.wmsSkuNotify.response.WmsSkuNotifyRsp.class);
		}
		return Parser.convertJson2Object(rsp, com.best.javaSdk.wmsSkuNotify.response.WmsSkuNotifyRsp.class);

    }

}
