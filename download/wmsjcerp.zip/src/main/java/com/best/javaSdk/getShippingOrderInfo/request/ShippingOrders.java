package com.best.javaSdk.getShippingOrderInfo.request;

import java.util.List;


public class ShippingOrders {
	private List<String> shippingOrder;

    public List<String>  getShippingOrder()
    {
        return this.shippingOrder;
    }

    public void setShippingOrder(List<String>  value)
    {
        this.shippingOrder = value;
    }

}
