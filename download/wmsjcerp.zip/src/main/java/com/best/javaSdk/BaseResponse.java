package com.best.javaSdk;

public interface BaseResponse {
}
