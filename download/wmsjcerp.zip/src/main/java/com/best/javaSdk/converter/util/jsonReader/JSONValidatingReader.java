package com.best.javaSdk.converter.util.jsonReader;

public class JSONValidatingReader extends JSONReader {
    public static final Object INVALID = new Object();
    private com.best.javaSdk.converter.util.jsonReader.JSONValidator validator;
    
    public JSONValidatingReader(com.best.javaSdk.converter.util.jsonReader.JSONValidator validator) {
        this.validator = validator;
    }
    
    public JSONValidatingReader(com.best.javaSdk.converter.util.jsonReader.ExceptionErrorListener listener) {
        this(new com.best.javaSdk.converter.util.jsonReader.JSONValidator(listener));
    }
    
/*    public JSONValidatingReader() {
        this(new StdoutStreamErrorListener());
    }*/

    public Object read(String string) {
        if (!validator.validate(string)) return INVALID;
        return super.read(string);
    }
}
