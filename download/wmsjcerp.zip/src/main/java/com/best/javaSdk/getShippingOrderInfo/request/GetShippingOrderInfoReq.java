package com.best.javaSdk.getShippingOrderInfo.request;

import com.best.javaSdk.BaseRequest;
import com.best.javaSdk.BaseResponse;
import com.best.javaSdk.Parser;


public class GetShippingOrderInfoReq implements BaseRequest {
	private String customerCode;
	private String warehouseCode;
	private ShippingOrders shippingOrders;

    public String getCustomerCode()
    {
        return this.customerCode;
    }

    public void setCustomerCode(String value)
    {
        this.customerCode = value;
    }

    public String getWarehouseCode()
    {
        return this.warehouseCode;
    }

    public void setWarehouseCode(String value)
    {
        this.warehouseCode = value;
    }

    public ShippingOrders getShippingOrders()
    {
        return this.shippingOrders;
    }

    public void setShippingOrders(ShippingOrders value)
    {
        this.shippingOrders = value;
    }

    public String obtainServiceType() {
        return "GetShippingOrderInfo";
    }

    public BaseResponse makeResponse(String rsp, String format) {
        if ("xml".equalsIgnoreCase(format)) {
			return Parser.coverXml2Object(rsp, com.best.javaSdk.getShippingOrderInfo.response.GetShippingOrderInfoRsp.class);
		}
		return Parser.convertJson2Object(rsp, com.best.javaSdk.getShippingOrderInfo.response.GetShippingOrderInfoRsp.class);

    }

}
