package com.best.javaSdk.tmsTraceQuery.response;



public class OrderTrace {
	private String traceTime;
	private String traceType;
	private String traceDesc;
	private String traceCity;
	private String operator;
	private String contacter;
	private String contactPhone;
	private String siteType;
	private String siteCode;
	private String siteName;

    public String getTraceTime()
    {
        return this.traceTime;
    }

    public void setTraceTime(String value)
    {
        this.traceTime = value;
    }

    public String getTraceType()
    {
        return this.traceType;
    }

    public void setTraceType(String value)
    {
        this.traceType = value;
    }

    public String getTraceDesc()
    {
        return this.traceDesc;
    }

    public void setTraceDesc(String value)
    {
        this.traceDesc = value;
    }

    public String getTraceCity()
    {
        return this.traceCity;
    }

    public void setTraceCity(String value)
    {
        this.traceCity = value;
    }

    public String getOperator()
    {
        return this.operator;
    }

    public void setOperator(String value)
    {
        this.operator = value;
    }

    public String getContacter()
    {
        return this.contacter;
    }

    public void setContacter(String value)
    {
        this.contacter = value;
    }

    public String getContactPhone()
    {
        return this.contactPhone;
    }

    public void setContactPhone(String value)
    {
        this.contactPhone = value;
    }

    public String getSiteType()
    {
        return this.siteType;
    }

    public void setSiteType(String value)
    {
        this.siteType = value;
    }

    public String getSiteCode()
    {
        return this.siteCode;
    }

    public void setSiteCode(String value)
    {
        this.siteCode = value;
    }

    public String getSiteName()
    {
        return this.siteName;
    }

    public void setSiteName(String value)
    {
        this.siteName = value;
    }


}
