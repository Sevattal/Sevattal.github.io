package com.best.javaSdk.converter.util.jsonReader;

public class StdoutStreamErrorListener extends com.best.javaSdk.converter.util.jsonReader.BufferErrorListener {
    
    public void end() {
        System.out.print(buffer.toString());
    }
}
