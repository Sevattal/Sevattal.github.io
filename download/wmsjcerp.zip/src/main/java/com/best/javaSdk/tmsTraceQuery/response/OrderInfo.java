package com.best.javaSdk.tmsTraceQuery.response;


public class OrderInfo {
	private String customerCode;
	private String customerName;
	private String projectCode;
	private String orderCode;
	private String status;
	private String portalUrl;
	private String currentStatusDatetime;
	private String currentStatusLocation;
	private String currentStatusDescription;
	private String currentStatusUpdator;
	private Shippings shippings;
	private OrderTraces orderTraces;
	private String tmsCode;
	private Items items;

    public String getCustomerCode()
    {
        return this.customerCode;
    }

    public void setCustomerCode(String value)
    {
        this.customerCode = value;
    }

    public String getCustomerName()
    {
        return this.customerName;
    }

    public void setCustomerName(String value)
    {
        this.customerName = value;
    }

    public String getProjectCode()
    {
        return this.projectCode;
    }

    public void setProjectCode(String value)
    {
        this.projectCode = value;
    }

    public String getOrderCode()
    {
        return this.orderCode;
    }

    public void setOrderCode(String value)
    {
        this.orderCode = value;
    }

    public String getStatus()
    {
        return this.status;
    }

    public void setStatus(String value)
    {
        this.status = value;
    }

    public String getPortalUrl()
    {
        return this.portalUrl;
    }

    public void setPortalUrl(String value)
    {
        this.portalUrl = value;
    }

    public String getCurrentStatusDatetime()
    {
        return this.currentStatusDatetime;
    }

    public void setCurrentStatusDatetime(String value)
    {
        this.currentStatusDatetime = value;
    }

    public String getCurrentStatusLocation()
    {
        return this.currentStatusLocation;
    }

    public void setCurrentStatusLocation(String value)
    {
        this.currentStatusLocation = value;
    }

    public String getCurrentStatusDescription()
    {
        return this.currentStatusDescription;
    }

    public void setCurrentStatusDescription(String value)
    {
        this.currentStatusDescription = value;
    }

    public String getCurrentStatusUpdator()
    {
        return this.currentStatusUpdator;
    }

    public void setCurrentStatusUpdator(String value)
    {
        this.currentStatusUpdator = value;
    }

    public Shippings getShippings()
    {
        return this.shippings;
    }

    public void setShippings(Shippings value)
    {
        this.shippings = value;
    }

    public OrderTraces getOrderTraces()
    {
        return this.orderTraces;
    }

    public void setOrderTraces(OrderTraces value)
    {
        this.orderTraces = value;
    }

    public String getTmsCode()
    {
        return this.tmsCode;
    }

    public void setTmsCode(String value)
    {
        this.tmsCode = value;
    }

    public Items getItems()
    {
        return this.items;
    }

    public void setItems(Items value)
    {
        this.items = value;
    }


}
