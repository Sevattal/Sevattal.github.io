package com.best.javaSdk.twSoNotify.request;



public class ReferenceReq {
	private String outorderType;
	private String outorderValue;

    public String getOutorderType()
    {
        return this.outorderType;
    }

    public void setOutorderType(String value)
    {
        this.outorderType = value;
    }

    public String getOutorderValue()
    {
        return this.outorderValue;
    }

    public void setOutorderValue(String value)
    {
        this.outorderValue = value;
    }


}
