package com.best.javaSdk.getShippingOrderInfo.response;

import java.util.List;


public class TrackingInfoList {
	private List<TrackingInfo> trackingInfo;

    public List<TrackingInfo>  getTrackingInfo()
    {
        return this.trackingInfo;
    }

    public void setTrackingInfo(List<TrackingInfo>  value)
    {
        this.trackingInfo = value;
    }

}
