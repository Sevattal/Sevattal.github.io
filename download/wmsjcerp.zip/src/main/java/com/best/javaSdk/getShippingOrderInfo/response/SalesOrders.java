package com.best.javaSdk.getShippingOrderInfo.response;

import java.util.List;


public class SalesOrders {
	private List<SalesOrder> salesOrder;

    public List<SalesOrder>  getSalesOrder()
    {
        return this.salesOrder;
    }

    public void setSalesOrder(List<SalesOrder>  value)
    {
        this.salesOrder = value;
    }

}
