package com.best.javaSdk.twSoNotify.request;


public class Service {
	private String serviceDefinitionCode;
	private String remark;
	private ServiceCodeList serviceCodeList;

    public String getServiceDefinitionCode()
    {
        return this.serviceDefinitionCode;
    }

    public void setServiceDefinitionCode(String value)
    {
        this.serviceDefinitionCode = value;
    }

    public String getRemark()
    {
        return this.remark;
    }

    public void setRemark(String value)
    {
        this.remark = value;
    }

    public ServiceCodeList getServiceCodeList()
    {
        return this.serviceCodeList;
    }

    public void setServiceCodeList(ServiceCodeList value)
    {
        this.serviceCodeList = value;
    }


}
