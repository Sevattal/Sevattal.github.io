package com.best.javaSdk.tmsGpsQuery.response;



public class ObSourceConcernedGpsInfo {
	private String address;
	private double longitude;
	private double latitude;

    public String getAddress()
    {
        return this.address;
    }

    public void setAddress(String value)
    {
        this.address = value;
    }

    public double getLongitude()
    {
        return this.longitude;
    }

    public void setLongitude(double value)
    {
        this.longitude = value;
    }

    public double getLatitude()
    {
        return this.latitude;
    }

    public void setLatitude(double value)
    {
        this.latitude = value;
    }


}
