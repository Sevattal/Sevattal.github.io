package com.best.javaSdk.getShippingOrderInfo.response;


public class SalesOrder {
	private String orderCode;
	private String note;
	private ShippingOrders shippingOrders;

    public String getOrderCode()
    {
        return this.orderCode;
    }

    public void setOrderCode(String value)
    {
        this.orderCode = value;
    }

    public String getNote()
    {
        return this.note;
    }

    public void setNote(String value)
    {
        this.note = value;
    }

    public ShippingOrders getShippingOrders()
    {
        return this.shippingOrders;
    }

    public void setShippingOrders(ShippingOrders value)
    {
        this.shippingOrders = value;
    }


}
