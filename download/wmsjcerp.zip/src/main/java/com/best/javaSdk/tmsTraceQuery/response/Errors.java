package com.best.javaSdk.tmsTraceQuery.response;

import java.util.List;


public class Errors {
	private List<java.lang.Error> error;

    public List<java.lang.Error>  getError()
    {
        return this.error;
    }

    public void setError(List<java.lang.Error>  value)
    {
        this.error = value;
    }

}
