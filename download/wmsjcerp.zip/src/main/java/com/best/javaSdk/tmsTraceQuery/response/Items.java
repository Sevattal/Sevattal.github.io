package com.best.javaSdk.tmsTraceQuery.response;

import java.util.List;


public class Items {
	private List<Item> item;

    public List<Item>  getItem()
    {
        return this.item;
    }

    public void setItem(List<Item>  value)
    {
        this.item = value;
    }

}
