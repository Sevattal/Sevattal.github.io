package com.best.javaSdk.tmsTraceQuery.response;


public class Shipping {
	private String logisticsCode;
	private String logisticsName;
	private String shipmentCode;
	private String transportMode;
	private String sourceLocationAddress;
	private String destLocationAddress;
	private String operateTime;
	private String operator;
	private String driverName;
	private String driverPhone;
	private String operateDescription;
	private String shipmentStatus;
	private boolean cod;
	private double codAmount;
	private double goodsValue;
	private double cheapAmount;
	private String codStatus;
	private String codPayType;
	private Items items;
	private Traces traces;
	private String referenceShipCode;

    public String getLogisticsCode()
    {
        return this.logisticsCode;
    }

    public void setLogisticsCode(String value)
    {
        this.logisticsCode = value;
    }

    public String getLogisticsName()
    {
        return this.logisticsName;
    }

    public void setLogisticsName(String value)
    {
        this.logisticsName = value;
    }

    public String getShipmentCode()
    {
        return this.shipmentCode;
    }

    public void setShipmentCode(String value)
    {
        this.shipmentCode = value;
    }

    public String getTransportMode()
    {
        return this.transportMode;
    }

    public void setTransportMode(String value)
    {
        this.transportMode = value;
    }

    public String getSourceLocationAddress()
    {
        return this.sourceLocationAddress;
    }

    public void setSourceLocationAddress(String value)
    {
        this.sourceLocationAddress = value;
    }

    public String getDestLocationAddress()
    {
        return this.destLocationAddress;
    }

    public void setDestLocationAddress(String value)
    {
        this.destLocationAddress = value;
    }

    public String getOperateTime()
    {
        return this.operateTime;
    }

    public void setOperateTime(String value)
    {
        this.operateTime = value;
    }

    public String getOperator()
    {
        return this.operator;
    }

    public void setOperator(String value)
    {
        this.operator = value;
    }

    public String getDriverName()
    {
        return this.driverName;
    }

    public void setDriverName(String value)
    {
        this.driverName = value;
    }

    public String getDriverPhone()
    {
        return this.driverPhone;
    }

    public void setDriverPhone(String value)
    {
        this.driverPhone = value;
    }

    public String getOperateDescription()
    {
        return this.operateDescription;
    }

    public void setOperateDescription(String value)
    {
        this.operateDescription = value;
    }

    public String getShipmentStatus()
    {
        return this.shipmentStatus;
    }

    public void setShipmentStatus(String value)
    {
        this.shipmentStatus = value;
    }

    public boolean getCod()
    {
        return this.cod;
    }

    public void setCod(boolean value)
    {
        this.cod = value;
    }

    public double getCodAmount()
    {
        return this.codAmount;
    }

    public void setCodAmount(double value)
    {
        this.codAmount = value;
    }

    public double getGoodsValue()
    {
        return this.goodsValue;
    }

    public void setGoodsValue(double value)
    {
        this.goodsValue = value;
    }

    public double getCheapAmount()
    {
        return this.cheapAmount;
    }

    public void setCheapAmount(double value)
    {
        this.cheapAmount = value;
    }

    public String getCodStatus()
    {
        return this.codStatus;
    }

    public void setCodStatus(String value)
    {
        this.codStatus = value;
    }

    public String getCodPayType()
    {
        return this.codPayType;
    }

    public void setCodPayType(String value)
    {
        this.codPayType = value;
    }

    public Items getItems()
    {
        return this.items;
    }

    public void setItems(Items value)
    {
        this.items = value;
    }

    public Traces getTraces()
    {
        return this.traces;
    }

    public void setTraces(Traces value)
    {
        this.traces = value;
    }

    public String getReferenceShipCode()
    {
        return this.referenceShipCode;
    }

    public void setReferenceShipCode(String value)
    {
        this.referenceShipCode = value;
    }


}
