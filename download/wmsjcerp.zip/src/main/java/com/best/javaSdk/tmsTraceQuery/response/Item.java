package com.best.javaSdk.tmsTraceQuery.response;



public class Item {
	private String itemCode;
	private String itemName;
	private String packageUomCode;
	private long count;
	private double weight;
	private double volume;

    public String getItemCode()
    {
        return this.itemCode;
    }

    public void setItemCode(String value)
    {
        this.itemCode = value;
    }

    public String getItemName()
    {
        return this.itemName;
    }

    public void setItemName(String value)
    {
        this.itemName = value;
    }

    public String getPackageUomCode()
    {
        return this.packageUomCode;
    }

    public void setPackageUomCode(String value)
    {
        this.packageUomCode = value;
    }

    public long getCount()
    {
        return this.count;
    }

    public void setCount(long value)
    {
        this.count = value;
    }

    public double getWeight()
    {
        return this.weight;
    }

    public void setWeight(double value)
    {
        this.weight = value;
    }

    public double getVolume()
    {
        return this.volume;
    }

    public void setVolume(double value)
    {
        this.volume = value;
    }


}
