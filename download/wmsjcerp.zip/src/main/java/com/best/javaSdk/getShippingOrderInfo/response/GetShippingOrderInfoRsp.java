package com.best.javaSdk.getShippingOrderInfo.response;

import com.best.javaSdk.BaseResponse;


public class GetShippingOrderInfoRsp implements BaseResponse {
	private String flag;
	private String note;
	private Errors errors;
	private SalesOrders salesOrders;

    public String getFlag()
    {
        return this.flag;
    }

    public void setFlag(String value)
    {
        this.flag = value;
    }

    public String getNote()
    {
        return this.note;
    }

    public void setNote(String value)
    {
        this.note = value;
    }

    public Errors getErrors()
    {
        return this.errors;
    }

    public void setErrors(Errors value)
    {
        this.errors = value;
    }

    public SalesOrders getSalesOrders()
    {
        return this.salesOrders;
    }

    public void setSalesOrders(SalesOrders value)
    {
        this.salesOrders = value;
    }


}
