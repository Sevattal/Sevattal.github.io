package com.best.javaSdk.tmsTraceQuery.response;



public class Trace {
	private String opTime;
	private String opStatus;
	private String opDesc;
	private String operator;
	private String opLocation;

    public String getOpTime()
    {
        return this.opTime;
    }

    public void setOpTime(String value)
    {
        this.opTime = value;
    }

    public String getOpStatus()
    {
        return this.opStatus;
    }

    public void setOpStatus(String value)
    {
        this.opStatus = value;
    }

    public String getOpDesc()
    {
        return this.opDesc;
    }

    public void setOpDesc(String value)
    {
        this.opDesc = value;
    }

    public String getOperator()
    {
        return this.operator;
    }

    public void setOperator(String value)
    {
        this.operator = value;
    }

    public String getOpLocation()
    {
        return this.opLocation;
    }

    public void setOpLocation(String value)
    {
        this.opLocation = value;
    }


}
