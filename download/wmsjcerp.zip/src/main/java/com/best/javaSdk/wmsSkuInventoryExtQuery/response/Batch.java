package com.best.javaSdk.wmsSkuInventoryExtQuery.response;



public class Batch {
	private int quantity;
	private int frozenQuantity;
	private String fixStatusCode;
	private String productionDate;
	private String expiryDate;
	private String lotAtt01;
	private String lotAtt02;
	private String lotAtt03;
	private String lotAtt04;
	private String lotAtt05;
	private String lotAtt06;
	private String lotAtt07;
	private String lotAtt08;
	private String lotAtt09;
	private String lotAtt10;
	private String lotAtt11;
	private String lotAtt12;

    public int getQuantity()
    {
        return this.quantity;
    }

    public void setQuantity(int value)
    {
        this.quantity = value;
    }

    public int getFrozenQuantity()
    {
        return this.frozenQuantity;
    }

    public void setFrozenQuantity(int value)
    {
        this.frozenQuantity = value;
    }

    public String getFixStatusCode()
    {
        return this.fixStatusCode;
    }

    public void setFixStatusCode(String value)
    {
        this.fixStatusCode = value;
    }

    public String getProductionDate()
    {
        return this.productionDate;
    }

    public void setProductionDate(String value)
    {
        this.productionDate = value;
    }

    public String getExpiryDate()
    {
        return this.expiryDate;
    }

    public void setExpiryDate(String value)
    {
        this.expiryDate = value;
    }

    public String getLotAtt01()
    {
        return this.lotAtt01;
    }

    public void setLotAtt01(String value)
    {
        this.lotAtt01 = value;
    }

    public String getLotAtt02()
    {
        return this.lotAtt02;
    }

    public void setLotAtt02(String value)
    {
        this.lotAtt02 = value;
    }

    public String getLotAtt03()
    {
        return this.lotAtt03;
    }

    public void setLotAtt03(String value)
    {
        this.lotAtt03 = value;
    }

    public String getLotAtt04()
    {
        return this.lotAtt04;
    }

    public void setLotAtt04(String value)
    {
        this.lotAtt04 = value;
    }

    public String getLotAtt05()
    {
        return this.lotAtt05;
    }

    public void setLotAtt05(String value)
    {
        this.lotAtt05 = value;
    }

    public String getLotAtt06()
    {
        return this.lotAtt06;
    }

    public void setLotAtt06(String value)
    {
        this.lotAtt06 = value;
    }

    public String getLotAtt07()
    {
        return this.lotAtt07;
    }

    public void setLotAtt07(String value)
    {
        this.lotAtt07 = value;
    }

    public String getLotAtt08()
    {
        return this.lotAtt08;
    }

    public void setLotAtt08(String value)
    {
        this.lotAtt08 = value;
    }

    public String getLotAtt09()
    {
        return this.lotAtt09;
    }

    public void setLotAtt09(String value)
    {
        this.lotAtt09 = value;
    }

    public String getLotAtt10()
    {
        return this.lotAtt10;
    }

    public void setLotAtt10(String value)
    {
        this.lotAtt10 = value;
    }

    public String getLotAtt11()
    {
        return this.lotAtt11;
    }

    public void setLotAtt11(String value)
    {
        this.lotAtt11 = value;
    }

    public String getLotAtt12()
    {
        return this.lotAtt12;
    }

    public void setLotAtt12(String value)
    {
        this.lotAtt12 = value;
    }


}
