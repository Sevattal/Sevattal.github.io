package com.best.javaSdk.wmsSkuInventoryExtQuery.request;

import com.best.javaSdk.BaseRequest;
import com.best.javaSdk.BaseResponse;
import com.best.javaSdk.Parser;


public class WmsSkuInventoryExtQueryReq implements BaseRequest {
	private String customerCode;
	private String warehouseCode;
	private Products products;

    public String getCustomerCode()
    {
        return this.customerCode;
    }

    public void setCustomerCode(String value)
    {
        this.customerCode = value;
    }

    public String getWarehouseCode()
    {
        return this.warehouseCode;
    }

    public void setWarehouseCode(String value)
    {
        this.warehouseCode = value;
    }

    public Products getProducts()
    {
        return this.products;
    }

    public void setProducts(Products value)
    {
        this.products = value;
    }

    public String obtainServiceType() {
        return "WMS_SKU_INVENTORY_EXT_QUERY";
    }

    public BaseResponse makeResponse(String rsp, String format) {
        if ("xml".equalsIgnoreCase(format)) {
			return Parser.coverXml2Object(rsp, com.best.javaSdk.wmsSkuInventoryExtQuery.response.WmsSkuInventoryExtQueryRsp.class);
		}
		return Parser.convertJson2Object(rsp, com.best.javaSdk.wmsSkuInventoryExtQuery.response.WmsSkuInventoryExtQueryRsp.class);

    }

}
