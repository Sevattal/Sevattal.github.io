package com.best.javaSdk.tmsTraceQuery.response;

import java.util.List;


public class OrderInfos {
	private List<OrderInfo> orderInfo;

    public List<OrderInfo>  getOrderInfo()
    {
        return this.orderInfo;
    }

    public void setOrderInfo(List<OrderInfo>  value)
    {
        this.orderInfo = value;
    }

}
