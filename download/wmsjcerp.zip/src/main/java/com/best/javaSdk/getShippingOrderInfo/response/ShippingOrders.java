package com.best.javaSdk.getShippingOrderInfo.response;

import java.util.List;


public class ShippingOrders {
	private List<ShippingOrder> shippingOrder;

    public List<ShippingOrder>  getShippingOrder()
    {
        return this.shippingOrder;
    }

    public void setShippingOrder(List<ShippingOrder>  value)
    {
        this.shippingOrder = value;
    }

}
