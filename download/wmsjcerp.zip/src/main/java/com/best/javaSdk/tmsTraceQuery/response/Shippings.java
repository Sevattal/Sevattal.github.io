package com.best.javaSdk.tmsTraceQuery.response;

import java.util.List;


public class Shippings {
	private List<Shipping> shipping;

    public List<Shipping>  getShipping()
    {
        return this.shipping;
    }

    public void setShipping(List<Shipping>  value)
    {
        this.shipping = value;
    }

}
