package com.best.javaSdk.tmsTraceQuery.response;

import java.util.List;


public class Traces {
	private List<Trace> trace;

    public List<Trace>  getTrace()
    {
        return this.trace;
    }

    public void setTrace(List<Trace>  value)
    {
        this.trace = value;
    }

}
