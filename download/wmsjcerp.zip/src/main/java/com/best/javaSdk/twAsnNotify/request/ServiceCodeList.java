package com.best.javaSdk.twAsnNotify.request;

import java.util.List;


public class ServiceCodeList {
	private List<ServiceCode> serviceCode;

    public List<ServiceCode>  getServiceCode()
    {
        return this.serviceCode;
    }

    public void setServiceCode(List<ServiceCode>  value)
    {
        this.serviceCode = value;
    }

}
