package com.best.javaSdk.twSoNotify.request;

import java.util.List;


public class ServiceCodeList {
	private List<ServiceCode> serviceCode;

    public List<ServiceCode>  getServiceCode()
    {
        return this.serviceCode;
    }

    public void setServiceCode(List<ServiceCode>  value)
    {
        this.serviceCode = value;
    }

}
