package com.best.javaSdk.twAsnNotify.request;

import java.util.List;


public class ServiceList {
	private List<Service> service;

    public List<Service>  getService()
    {
        return this.service;
    }

    public void setService(List<Service>  value)
    {
        this.service = value;
    }

}
