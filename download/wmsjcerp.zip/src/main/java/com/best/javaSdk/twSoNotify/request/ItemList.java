package com.best.javaSdk.twSoNotify.request;

import java.util.List;


public class ItemList {
	private List<Item> item;

    public List<Item>  getItem()
    {
        return this.item;
    }

    public void setItem(List<Item>  value)
    {
        this.item = value;
    }

}
