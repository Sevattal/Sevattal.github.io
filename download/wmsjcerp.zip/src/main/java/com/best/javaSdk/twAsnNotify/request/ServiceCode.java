package com.best.javaSdk.twAsnNotify.request;



public class ServiceCode {
	private String serviceDefParameterCode;
	private String actualValue;

    public String getServiceDefParameterCode()
    {
        return this.serviceDefParameterCode;
    }

    public void setServiceDefParameterCode(String value)
    {
        this.serviceDefParameterCode = value;
    }

    public String getActualValue()
    {
        return this.actualValue;
    }

    public void setActualValue(String value)
    {
        this.actualValue = value;
    }


}
