package com.best.javaSdk.wmsSkuNotify.response;

import com.best.javaSdk.BaseResponse;


public class WmsSkuNotifyRsp implements BaseResponse {
	private boolean result;
	private String note;
	private Errors errors;

    public boolean getResult()
    {
        return this.result;
    }

    public void setResult(boolean value)
    {
        this.result = value;
    }

    public String getNote()
    {
        return this.note;
    }

    public void setNote(String value)
    {
        this.note = value;
    }

    public Errors getErrors()
    {
        return this.errors;
    }

    public void setErrors(Errors value)
    {
        this.errors = value;
    }


}
