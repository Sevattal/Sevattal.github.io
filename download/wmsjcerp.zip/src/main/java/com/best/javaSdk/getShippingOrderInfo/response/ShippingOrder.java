package com.best.javaSdk.getShippingOrderInfo.response;


public class ShippingOrder {
	private String status;
	private TrackingInfoList trackingInfoList;
	private String logisticsProviderCode;
	private String shippingOrderNo;

    public String getStatus()
    {
        return this.status;
    }

    public void setStatus(String value)
    {
        this.status = value;
    }

    public TrackingInfoList getTrackingInfoList()
    {
        return this.trackingInfoList;
    }

    public void setTrackingInfoList(TrackingInfoList value)
    {
        this.trackingInfoList = value;
    }

    public String getLogisticsProviderCode()
    {
        return this.logisticsProviderCode;
    }

    public void setLogisticsProviderCode(String value)
    {
        this.logisticsProviderCode = value;
    }

    public String getShippingOrderNo()
    {
        return this.shippingOrderNo;
    }

    public void setShippingOrderNo(String value)
    {
        this.shippingOrderNo = value;
    }


}
