package com.best.javaSdk.twSoNotify.request;

import java.util.List;


public class ReferenceReqList {
	private List<ReferenceReq> referenceReq;

    public List<ReferenceReq>  getReferenceReq()
    {
        return this.referenceReq;
    }

    public void setReferenceReq(List<ReferenceReq>  value)
    {
        this.referenceReq = value;
    }

}
