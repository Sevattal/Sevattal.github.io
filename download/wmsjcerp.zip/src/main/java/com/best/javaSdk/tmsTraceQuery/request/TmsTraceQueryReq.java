package com.best.javaSdk.tmsTraceQuery.request;

import com.best.javaSdk.BaseRequest;
import com.best.javaSdk.BaseResponse;
import com.best.javaSdk.Parser;


public class TmsTraceQueryReq implements BaseRequest {
	private String orderCode;
	private String shipmentCode;
	private String customerCode;
	private String createTimeFrom;
	private String createTimeTo;

    public String getOrderCode()
    {
        return this.orderCode;
    }

    public void setOrderCode(String value)
    {
        this.orderCode = value;
    }

    public String getShipmentCode()
    {
        return this.shipmentCode;
    }

    public void setShipmentCode(String value)
    {
        this.shipmentCode = value;
    }

    public String getCustomerCode()
    {
        return this.customerCode;
    }

    public void setCustomerCode(String value)
    {
        this.customerCode = value;
    }

    public String getCreateTimeFrom()
    {
        return this.createTimeFrom;
    }

    public void setCreateTimeFrom(String value)
    {
        this.createTimeFrom = value;
    }

    public String getCreateTimeTo()
    {
        return this.createTimeTo;
    }

    public void setCreateTimeTo(String value)
    {
        this.createTimeTo = value;
    }

    public String obtainServiceType() {
        return "TMS_TRACE_QUERY";
    }

    public BaseResponse makeResponse(String rsp, String format) {
        if ("xml".equalsIgnoreCase(format)) {
			return Parser.coverXml2Object(rsp, com.best.javaSdk.tmsTraceQuery.response.TmsTraceQueryRsp.class);
		}
		return Parser.convertJson2Object(rsp, com.best.javaSdk.tmsTraceQuery.response.TmsTraceQueryRsp.class);

    }

}
