package com.best.javaSdk.twSoNotify.request;



public class Item {
	private int lineNo;
	private String itemSkuCode;
	private String itemName;
	private int itemQuantity;
	private int packageCount;
	private String uomCode;
	private double weight;
	private double volume;
	private double volumeWeight;
	private double unitPrice;
	private double declaredValue;
	private String fixStatusCode;
	private String productionDate;
	private String expiryDate;
	private String lotAtt01;
	private String lotAtt02;
	private String lotAtt03;
	private String lotAtt04;
	private String lotAtt05;
	private String lotAtt06;
	private String providerCode;
	private String providerFrom;
	private String providerName;
	private String packCode;
	private boolean udfFlag;
	private String udf1;
	private String udf2;
	private String udf3;
	private String udf4;
	private String udf5;
	private String udf6;
	private String udf7;
	private String udf8;
	private String packageStandard;
	private String remark;
	private double decimalQuantity;
	private String packageName;

    public int getLineNo()
    {
        return this.lineNo;
    }

    public void setLineNo(int value)
    {
        this.lineNo = value;
    }

    public String getItemSkuCode()
    {
        return this.itemSkuCode;
    }

    public void setItemSkuCode(String value)
    {
        this.itemSkuCode = value;
    }

    public String getItemName()
    {
        return this.itemName;
    }

    public void setItemName(String value)
    {
        this.itemName = value;
    }

    public int getItemQuantity()
    {
        return this.itemQuantity;
    }

    public void setItemQuantity(int value)
    {
        this.itemQuantity = value;
    }

    public int getPackageCount()
    {
        return this.packageCount;
    }

    public void setPackageCount(int value)
    {
        this.packageCount = value;
    }

    public String getUomCode()
    {
        return this.uomCode;
    }

    public void setUomCode(String value)
    {
        this.uomCode = value;
    }

    public double getWeight()
    {
        return this.weight;
    }

    public void setWeight(double value)
    {
        this.weight = value;
    }

    public double getVolume()
    {
        return this.volume;
    }

    public void setVolume(double value)
    {
        this.volume = value;
    }

    public double getVolumeWeight()
    {
        return this.volumeWeight;
    }

    public void setVolumeWeight(double value)
    {
        this.volumeWeight = value;
    }

    public double getUnitPrice()
    {
        return this.unitPrice;
    }

    public void setUnitPrice(double value)
    {
        this.unitPrice = value;
    }

    public double getDeclaredValue()
    {
        return this.declaredValue;
    }

    public void setDeclaredValue(double value)
    {
        this.declaredValue = value;
    }

    public String getFixStatusCode()
    {
        return this.fixStatusCode;
    }

    public void setFixStatusCode(String value)
    {
        this.fixStatusCode = value;
    }

    public String getProductionDate()
    {
        return this.productionDate;
    }

    public void setProductionDate(String value)
    {
        this.productionDate = value;
    }

    public String getExpiryDate()
    {
        return this.expiryDate;
    }

    public void setExpiryDate(String value)
    {
        this.expiryDate = value;
    }

    public String getLotAtt01()
    {
        return this.lotAtt01;
    }

    public void setLotAtt01(String value)
    {
        this.lotAtt01 = value;
    }

    public String getLotAtt02()
    {
        return this.lotAtt02;
    }

    public void setLotAtt02(String value)
    {
        this.lotAtt02 = value;
    }

    public String getLotAtt03()
    {
        return this.lotAtt03;
    }

    public void setLotAtt03(String value)
    {
        this.lotAtt03 = value;
    }

    public String getLotAtt04()
    {
        return this.lotAtt04;
    }

    public void setLotAtt04(String value)
    {
        this.lotAtt04 = value;
    }

    public String getLotAtt05()
    {
        return this.lotAtt05;
    }

    public void setLotAtt05(String value)
    {
        this.lotAtt05 = value;
    }

    public String getLotAtt06()
    {
        return this.lotAtt06;
    }

    public void setLotAtt06(String value)
    {
        this.lotAtt06 = value;
    }

    public String getProviderCode()
    {
        return this.providerCode;
    }

    public void setProviderCode(String value)
    {
        this.providerCode = value;
    }

    public String getProviderFrom()
    {
        return this.providerFrom;
    }

    public void setProviderFrom(String value)
    {
        this.providerFrom = value;
    }

    public String getProviderName()
    {
        return this.providerName;
    }

    public void setProviderName(String value)
    {
        this.providerName = value;
    }

    public String getPackCode()
    {
        return this.packCode;
    }

    public void setPackCode(String value)
    {
        this.packCode = value;
    }

    public boolean getUdfFlag()
    {
        return this.udfFlag;
    }

    public void setUdfFlag(boolean value)
    {
        this.udfFlag = value;
    }

    public String getUdf1()
    {
        return this.udf1;
    }

    public void setUdf1(String value)
    {
        this.udf1 = value;
    }

    public String getUdf2()
    {
        return this.udf2;
    }

    public void setUdf2(String value)
    {
        this.udf2 = value;
    }

    public String getUdf3()
    {
        return this.udf3;
    }

    public void setUdf3(String value)
    {
        this.udf3 = value;
    }

    public String getUdf4()
    {
        return this.udf4;
    }

    public void setUdf4(String value)
    {
        this.udf4 = value;
    }

    public String getUdf5()
    {
        return this.udf5;
    }

    public void setUdf5(String value)
    {
        this.udf5 = value;
    }

    public String getUdf6()
    {
        return this.udf6;
    }

    public void setUdf6(String value)
    {
        this.udf6 = value;
    }

    public String getUdf7()
    {
        return this.udf7;
    }

    public void setUdf7(String value)
    {
        this.udf7 = value;
    }

    public String getUdf8()
    {
        return this.udf8;
    }

    public void setUdf8(String value)
    {
        this.udf8 = value;
    }

    public String getPackageStandard()
    {
        return this.packageStandard;
    }

    public void setPackageStandard(String value)
    {
        this.packageStandard = value;
    }

    public String getRemark()
    {
        return this.remark;
    }

    public void setRemark(String value)
    {
        this.remark = value;
    }

    public double getDecimalQuantity()
    {
        return this.decimalQuantity;
    }

    public void setDecimalQuantity(double value)
    {
        this.decimalQuantity = value;
    }

    public String getPackageName()
    {
        return this.packageName;
    }

    public void setPackageName(String value)
    {
        this.packageName = value;
    }

    @Override
    public String toString() {
        return "Item{" +
                "lineNo=" + lineNo +
                ", itemSkuCode='" + itemSkuCode + '\'' +
                ", itemName='" + itemName + '\'' +
                ", itemQuantity=" + itemQuantity +
                ", packageCount=" + packageCount +
                ", uomCode='" + uomCode + '\'' +
                ", weight=" + weight +
                ", volume=" + volume +
                ", volumeWeight=" + volumeWeight +
                ", unitPrice=" + unitPrice +
                ", declaredValue=" + declaredValue +
                ", fixStatusCode='" + fixStatusCode + '\'' +
                ", productionDate='" + productionDate + '\'' +
                ", expiryDate='" + expiryDate + '\'' +
                ", lotAtt01='" + lotAtt01 + '\'' +
                ", lotAtt02='" + lotAtt02 + '\'' +
                ", lotAtt03='" + lotAtt03 + '\'' +
                ", lotAtt04='" + lotAtt04 + '\'' +
                ", lotAtt05='" + lotAtt05 + '\'' +
                ", lotAtt06='" + lotAtt06 + '\'' +
                ", providerCode='" + providerCode + '\'' +
                ", providerFrom='" + providerFrom + '\'' +
                ", providerName='" + providerName + '\'' +
                ", packCode='" + packCode + '\'' +
                ", udfFlag=" + udfFlag +
                ", udf1='" + udf1 + '\'' +
                ", udf2='" + udf2 + '\'' +
                ", udf3='" + udf3 + '\'' +
                ", udf4='" + udf4 + '\'' +
                ", udf5='" + udf5 + '\'' +
                ", udf6='" + udf6 + '\'' +
                ", udf7='" + udf7 + '\'' +
                ", udf8='" + udf8 + '\'' +
                ", packageStandard='" + packageStandard + '\'' +
                ", remark='" + remark + '\'' +
                ", decimalQuantity=" + decimalQuantity +
                ", packageName='" + packageName + '\'' +
                '}';
    }
}
