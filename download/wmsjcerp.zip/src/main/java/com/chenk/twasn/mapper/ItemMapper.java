package com.chenk.twasn.mapper;


import com.best.javaSdk.twAsnNotify.request.Item;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository("TwAsnItemListMapper")
public interface ItemMapper {

    /*
    * 获取对应订单的产品信息
    * */
    public List<Item> selectItem(String orderCode);
}
