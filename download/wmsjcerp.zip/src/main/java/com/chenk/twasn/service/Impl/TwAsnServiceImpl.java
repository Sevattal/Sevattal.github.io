package com.chenk.twasn.service.Impl;

import com.best.javaSdk.twAsnNotify.request.*;
import com.best.javaSdk.twAsnNotify.response.TwAsnNotifyRsp;
import com.chenk.twasn.mapper.ItemMapper;
import com.chenk.twasn.mapper.ReceiverMapper;
import com.chenk.twasn.mapper.SenderMapper;
import com.chenk.twasn.mapper.TwAsnNotifyMapper;
import com.chenk.twasn.service.TwAsnService;
import com.chenk.util.BestPramUtil;
import com.chenk.util.ClientUtil;
import com.chenk.util.RandomUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class TwAsnServiceImpl  implements TwAsnService {

    @Autowired
    private  ItemMapper itemMapper;
    @Autowired
    private ReceiverMapper receiverMapper;
    @Autowired
    private SenderMapper senderMapper;
    @Autowired
    private TwAsnNotifyMapper twAsnNotifyMapper;

    private ItemList itemList = new ItemList();
    private List<Item> lists;
    private TwAsnNotifyReq Req = new TwAsnNotifyReq();
    private Sender sender = new Sender();
    private Receiver receiver = new Receiver();
    private ClientUtil clientUtil =new ClientUtil();
    private TwAsnNotifyRsp Rsp = new TwAsnNotifyRsp();
    private BestPramUtil bestPramUtil = new BestPramUtil();

    private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(TwAsnServiceImpl.class);

    /*
    * 注意sku同步接口同步的产品信息需要传入，否则入库单无法入库
    *
    * */
    @Override
    public boolean syncTwAsn(String orderCode) {

        /*
        * TwAsn Service 层开始信息提示
        * */
        LOGGER.info("TwAsn Service Start");

        /*
        * 判断是不是CRM电商仓库，若不是电商仓库直接返回false
        *
        * */
        if (!twAsnNotifyMapper.isCrmTwAsnNotify(orderCode).equalsIgnoreCase("31")){

            LOGGER.info("该订单不是药妆仓库的订单,不允许同步");
            return false;

        }else{
            LOGGER.info("该订单为药妆仓库,允许同步");
        }

        /*
        * 获取订单信息
        * */
        Req = twAsnNotifyMapper.selectTwAsnNotify(orderCode);
        LOGGER.info("获取的原入库订单信息为: " + Req.toString());

        /*
        * 判断入库订单的基础信息是否存在，若不存在则不允许同步
        * */
        if (Req.getOrderCode().equalsIgnoreCase("") || Req.getOrderCode().equalsIgnoreCase("null") ||
        Req.getOrderCode().isEmpty()){
            LOGGER.info("OrderCode 的值为空,不允许同步");
            return false;
        }
        if (Req.getOrderTime().isEmpty() || Req.getOrderTime().equalsIgnoreCase("") ||
        Req.getOrderTime().equalsIgnoreCase("null")){
            LOGGER.info("OrderTime 的值为空,不允许同步");
            return false;
        }

        /*
        * 获取订单产品信息
        * */
        lists = itemMapper.selectItem(orderCode);

        /*
        * 若订单产品为空,则不允许同步
        * */
        if (lists.size()==0){
            LOGGER.info("订单中没有产品信息,不允许同步");
            return false;
        }

        /*
        * 打印订单中产品的原始信息
        *
        * */
        LOGGER.info("订单中产品的原始信息");
        for (int i=0;i<lists.size();i++){
            LOGGER.info(lists.get(i).toString());
        }


        /*
        * 判断订单产品是否为多个，若为多个产品，则配置行号
        * 判断item那些必要值为空，则不允许同步
        * */
        for (int i=0;i<lists.size();i++){
            lists.get(i).setLineNo(i+1);
            /*
             * 判断产品信息必填数据是否有空值
             * */
            if (lists.get(i).getItemSkuCode().equalsIgnoreCase("null")||lists.get(i).getItemSkuCode().equalsIgnoreCase("")|| lists.get(i).getItemSkuCode().isEmpty()){
                LOGGER.info("ItemSkuCode 的值为空,不允许同步");
                return false;
            }
            if (lists.get(i).getItemName().equalsIgnoreCase("null") || lists.get(i).getItemName().equalsIgnoreCase("") || lists.get(i).getItemName().isEmpty()){
                LOGGER.info("ItemName 的值为空,不允许同步");
                return false;
            }
            if (lists.get(i).getItemQuantity() == 0){
                LOGGER.info("ItemQuantity 的值为空,不允许同步");
                return false;
            }
            if (lists.get(i).getPackageCount() == 0 ){
                LOGGER.info("PackageCount 的值为空,不允许同步");
                return false;
            }
            if (lists.get(i).getUomCode().equalsIgnoreCase("null") || lists.get(i).getUomCode().equalsIgnoreCase("") || lists.get(i).getUomCode().isEmpty()){
                LOGGER.info("UomCode 的值为空,不允许同步");
                return false;
                }
            }

        /*
        * 将itemList赋值给Req对象中
        * */
        itemList.setItem(lists);
        Req.setItemList(itemList);

        /*
        * 获取订单发送者信息
        * */
        sender = senderMapper.selectSender(orderCode);

        /*
        * 打印原发送者信息
        * */
        LOGGER.info("Sender 发送者原数据"+sender.toString());

        /*
        * 判断发送者信息
        * */
        if (sender.getName().equalsIgnoreCase("null") || sender.getName().equalsIgnoreCase("") ||sender.getName().isEmpty()){
            sender.setName("Name None");
            LOGGER.info("Sender Name 的值为空,设置为Name None");
        }
        if (sender.getCity().equalsIgnoreCase("null")|| sender.getCity().equalsIgnoreCase("") || sender.getCity().isEmpty()){
            sender.setCity("City None");
            LOGGER.info("City 的值为空,设置为City None");
        }
        if (sender.getAddress().equalsIgnoreCase("null")|| sender.getAddress().equalsIgnoreCase("") || sender.getAddress().isEmpty()){
            sender.setAddress("Address None");
            LOGGER.info("Address 的值为空,设置为Address None");
        }
        if (sender.getContactName().equalsIgnoreCase("null")|| sender.getContactName().equalsIgnoreCase("") || sender.getContactName().isEmpty()){
            sender.setContactName("ContactName None");
            LOGGER.info("ContactName 的值为空,设置为ContactName None");
        }
        if (sender.getDistrict().equalsIgnoreCase("null")|| sender.getDistrict().equalsIgnoreCase("") || sender.getDistrict().isEmpty()){
            sender.setDistrict("District None");
            LOGGER.info("District 的值为空,设置为District None");
        }
        if (sender.getPhone().equalsIgnoreCase("null")|| sender.getPhone().equalsIgnoreCase("")|| sender.getPhone().isEmpty()){
            sender.setPhone("Phone None");
            LOGGER.info("Phone 的值为空,设置为Phone None");
        }
        if (sender.getProvince().equalsIgnoreCase("null")|| sender.getProvince().equalsIgnoreCase("") ||sender.getProvince().isEmpty()){
            sender.setProvince("Province None");
            LOGGER.info("Province 的值为空,设置为Province None");
        }

        LOGGER.info("Sender 更改后 "+sender.toString());
        Req.setSender(sender);


        /*
        * 获取订单接收者信息,由于receiver接收者信息不全，传入假信息
        * */
        receiver = receiverMapper.selectReceiver(orderCode);

        /*
        * 打印原Receiver接收者信息
        * */
        LOGGER.info("Receiver 接收者原数据 "+receiver.toString());

        if (receiver.getName().equalsIgnoreCase("null") || receiver.getName().equalsIgnoreCase("" ) || receiver.getName().isEmpty()){
            receiver.setName("Name None");
            LOGGER.info("Receiver Name 的值为空,设置为Name None");
        }
        if (receiver.getCity().equalsIgnoreCase("null") || receiver.getCity().equalsIgnoreCase("") || receiver.getCity().isEmpty()) {
            receiver.setCity("City None");
            LOGGER.info("City Name 的值为空,设置为City None");
        }
        if (receiver.getAddress().equalsIgnoreCase("null") || receiver.getAddress().equalsIgnoreCase("") || receiver.getAddress().isEmpty()) {
            receiver.setAddress("Address None");
            LOGGER.info("Address Name 的值为空,设置为Address None");
        }
        if (receiver.getDistrict().equalsIgnoreCase("null") || receiver.getDistrict().equalsIgnoreCase("") || receiver.getDistrict().isEmpty()) {
            receiver.setDistrict("District None");
            LOGGER.info("District Name 的值为空,设置为District None");
        }
        if (receiver.getProvince().equalsIgnoreCase("null") || receiver.getProvince().equalsIgnoreCase("") || receiver.getProvince().isEmpty()) {
            receiver.setProvince("Province None");
            LOGGER.info("Province Name 的值为空,设置为Province None");
        }
        if (receiver.getPhone().equalsIgnoreCase("null") || receiver.getPhone().equalsIgnoreCase("") || receiver.getPhone().isEmpty()) {
            receiver.setPhone("Phone None");
            LOGGER.info("Phone Name 的值为空,设置为Phone None");
        }
        if (receiver.getContactName().equalsIgnoreCase("null") || receiver.getContactName().equalsIgnoreCase("") || receiver.getContactName().isEmpty()) {
            receiver.setContactName("ContactName None");
            LOGGER.info("ContactName Name 的值为空,设置为ContactName None");
        }

        LOGGER.info("Receiver 更改后 "+ receiver.toString());
        Req.setReceiver(receiver);


        /*
         * 配置百世仓配入库接口所必须参数参数
         * */
        Req.setCustomerCode(bestPramUtil.getCustomerCode());
        Req.setWarehouseCode(bestPramUtil.getWareHouseCode());
        Req.setProjectCode(bestPramUtil.getProjectCode());

        Req.setOperationFlag(bestPramUtil.getTwasnoperationFlag());
        Req.setActionType(bestPramUtil.getTwasnactionType());
        Req.setOperationTypeCode(bestPramUtil.getTwasnoperationTypeCode());

        /*
        * 传送json数据给百世
        * */
        Rsp = clientUtil.getClient().executed(Req);

        if (Rsp.getResult() == true){

            LOGGER.info("orderCode: " + orderCode + " 同步成功");
            return true;

        }else{
            /*
            * 输出错误结果
            * */
            LOGGER.info("orderCode: " + orderCode + " 同步失败,百世返回报错如下:");
            LOGGER.info("ErrorCode: "+Rsp.getErrorCode());
            LOGGER.info("ErrorDescription: "+Rsp.getErrorDescription());
            LOGGER.info("Note: "+Rsp.getNote());
            return false;

        }
    }
}
