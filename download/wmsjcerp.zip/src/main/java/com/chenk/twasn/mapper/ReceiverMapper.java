package com.chenk.twasn.mapper;


import com.best.javaSdk.twAsnNotify.request.Receiver;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository("TwAsnReceiverMapper")
public interface ReceiverMapper {

    /*
    * 获取收件人信息,没有使用
    * */
    public Receiver selectReceiver(String ReceiverCode);
}
