package com.chenk.twasn.service;

public interface TwAsnService {


    /*
    * 同步单个入库单
    * */
    public boolean syncTwAsn(String orderCode);


}
