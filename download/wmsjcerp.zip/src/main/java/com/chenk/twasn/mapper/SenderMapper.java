package com.chenk.twasn.mapper;


import com.best.javaSdk.twAsnNotify.request.Sender;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository("TwAsnSenderMapper")
public interface SenderMapper {
    /*
    * 获取发件人信息
    * */
    public Sender selectSender(String SenderCode);

}
