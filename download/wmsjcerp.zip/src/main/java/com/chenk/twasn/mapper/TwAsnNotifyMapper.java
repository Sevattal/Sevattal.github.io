package com.chenk.twasn.mapper;


import com.best.javaSdk.twAsnNotify.request.TwAsnNotifyReq;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository("TwAsnNotifyMapper")
public interface TwAsnNotifyMapper {

    /*
    * 查询所有入库单信息
    *
    * */
    public List<TwAsnNotifyReq> selectAllTwAsnNotify();

    /*
    * 获取所有没有同步的入库单信息(入库单主表)，但是这里面不包括Sender，Receiver，ItemList等信息
    * 以上需要的信息在service去调用对应的mapper去获取数据，然后使用set方法将数据设定到TwAsnNotify
    *
    * */
    public List<TwAsnNotifyReq> selectAllNoTwAsnNotify();

    /*
    * 查询指定单号的入库单信息
    *
    * */
    public TwAsnNotifyReq selectTwAsnNotify(String orderCode);

    /*
    * 若同步成功，更新主表同步状态信息
    * */
    public boolean twasnOk(String orderCode);

    /*
    * 部分入库同步
    * */
    public boolean twasnPartOk(String orderCode);

    /*
    * 获取仓库的编号
    * */
    public String isCrmTwAsnNotify(String orderCode);


}
