package com.chenk.wmsso.service;

import com.alibaba.fastjson.JSONObject;
import com.chenk.wmsso.domain.Product;
import com.chenk.wmsso.domain.StatusPush;

import java.util.List;

public interface WmsSoService {

    public boolean wmsso(JSONObject jsonObject);

}
