package com.chenk.wmsso.domain;

public class PackProduct {
    private String packSkuCode;
    private String packFixStatusCode;
    private int packQuantity;
    private double packDecimalQty;
    private String packProductionDate;
    private String packExpiryDate;
    private String packLotAtt01;
    private String packLotAtt02;
    private String packLotAtt03;
    private String packLotAtt04;
    private String packLotAtt05;
    private String packLotAtt06;
    private String packCode;
    private String packUomCode;

    public String getPackSkuCode() {
        return packSkuCode;
    }

    public void setPackSkuCode(String packSkuCode) {
        this.packSkuCode = packSkuCode;
    }

    public String getPackFixStatusCode() {
        return packFixStatusCode;
    }

    public void setPackFixStatusCode(String packFixStatusCode) {
        this.packFixStatusCode = packFixStatusCode;
    }

    public int getPackQuantity() {
        return packQuantity;
    }

    public void setPackQuantity(int packQuantity) {
        this.packQuantity = packQuantity;
    }

    public double getPackDecimalQty() {
        return packDecimalQty;
    }

    public void setPackDecimalQty(double packDecimalQty) {
        this.packDecimalQty = packDecimalQty;
    }

    public String getPackProductionDate() {
        return packProductionDate;
    }

    public void setPackProductionDate(String packProductionDate) {
        this.packProductionDate = packProductionDate;
    }

    public String getPackExpiryDate() {
        return packExpiryDate;
    }

    public void setPackExpiryDate(String packExpiryDate) {
        this.packExpiryDate = packExpiryDate;
    }

    public String getPackLotAtt01() {
        return packLotAtt01;
    }

    public void setPackLotAtt01(String packLotAtt01) {
        this.packLotAtt01 = packLotAtt01;
    }

    public String getPackLotAtt02() {
        return packLotAtt02;
    }

    public void setPackLotAtt02(String packLotAtt02) {
        this.packLotAtt02 = packLotAtt02;
    }

    public String getPackLotAtt03() {
        return packLotAtt03;
    }

    public void setPackLotAtt03(String packLotAtt03) {
        this.packLotAtt03 = packLotAtt03;
    }

    public String getPackLotAtt04() {
        return packLotAtt04;
    }

    public void setPackLotAtt04(String packLotAtt04) {
        this.packLotAtt04 = packLotAtt04;
    }

    public String getPackLotAtt05() {
        return packLotAtt05;
    }

    public void setPackLotAtt05(String packLotAtt05) {
        this.packLotAtt05 = packLotAtt05;
    }

    public String getPackLotAtt06() {
        return packLotAtt06;
    }

    public void setPackLotAtt06(String packLotAtt06) {
        this.packLotAtt06 = packLotAtt06;
    }

    public String getPackCode() {
        return packCode;
    }

    public void setPackCode(String packCode) {
        this.packCode = packCode;
    }

    public String getPackUomCode() {
        return packUomCode;
    }

    public void setPackUomCode(String packUomCode) {
        this.packUomCode = packUomCode;
    }
}
