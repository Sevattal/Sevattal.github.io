package com.chenk.wmsso.service.Impl;

import com.alibaba.fastjson.JSONObject;
import com.chenk.wmsso.domain.ChenkProduct;
import com.chenk.wmsso.domain.Products;
import com.chenk.wmsso.domain.StatusPush;
import com.chenk.wmsso.mapper.ChenkInventoryMapper;
import com.chenk.wmsso.mapper.ChenkProductMapper;
import com.chenk.wmsso.mapper.ProductMapper;
import com.chenk.wmsso.mapper.StatusPushMapper;
import com.chenk.wmsso.service.WmsSoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service
public class WmsSoServiceImpl implements WmsSoService {

    @Autowired
    private ProductMapper productMapper;
    @Autowired
    private StatusPushMapper statusPushMapper;
    @Autowired
    private ChenkProductMapper chenkProductMapper;
    @Autowired
    private ChenkInventoryMapper chenkInventoryMapper;

    private StatusPush statusPush;
    private List<ChenkProduct> list;
    private Products products = new Products();

    private static final org.slf4j.Logger LOGGER = (Logger) LoggerFactory.getLogger(WmsSoServiceImpl.class);

    @Transactional
    @Override
    public boolean wmsso(JSONObject jsonObject) {
        /*
         * 打印获取的参数即状态信息
         * */
        LOGGER.info("WmsSo Service update Start");
        LOGGER.info("WmsSo Service Get JsonObject: " + jsonObject.toJSONString());

        /*
         * 将JSONObject对象转换成statusPush对象
         * */
        LOGGER.info("WmsSo LocalJsonObject Change statusPush Object Start");
        statusPush=jsonObject.toJavaObject(StatusPush.class);
        LOGGER.info("WmsSo LocalJsonObject Change statusPush Object Ok");

        /*
        * 若订单不存在直接返回false
        * */
        if (statusPushMapper.countStatusPush(statusPush.getOrderCode()) != 1){

            LOGGER.info(statusPush.getOrderCode()+"订单不存在");
            return false;
        }

        /*
        * 判断订单状态是否为DELIVERED,若不为DELIVERED，则不允许同步数据
        * */
        if (statusPush.getOrderStatus().equalsIgnoreCase("DELIVERED")) {

            LOGGER.info("传入的数据为: DELIVERED 参数正确,允许同步");

        }else{

            LOGGER.info("传入的数据不为： DELIVERED");
            return false;

        }

        /*
         * 更新出库单表状态信息，即出库数量
         * */
        statusPushMapper.updateStatusPush(statusPush.getOrderCode());

        /*
         * 获取出库明细表信息
         *
         * */
        list = chenkProductMapper.selectChenkProduct(statusPush.getOrderCode());

        /*
         * 判断订单中的产品再库存中是否存在,
         * 存在则更新库存表
         * 不存在则报错
         *
         * */
        LOGGER.info("开始更新处理仓库库存信息");
        for (int i = 0; i<list.size();i++){
            if (chenkInventoryMapper.countChenkInventory(list.get(i).getItemSkuCode()) == 0){

                LOGGER.info("itemSkuCode: " + list.get(i).getItemSkuCode() + " 不存在于仓库库存表中,无法出库");
                return false;

            }else if (chenkInventoryMapper.countChenkInventory(list.get(i).getItemSkuCode()) ==1 ){

                /*
                * 若库存不足,则无法出库
                * 该查询为CRM电商库的库存信息
                *
                * */
                if (list.get(i).getUnloadedQuantity() > chenkInventoryMapper.selectChenkInventory(list.get(i).getItemSkuCode()).getCurrentQuantity()){

                    LOGGER.info("itemSkuCode: " + list.get(i).getItemSkuCode()+" 仓库库存不足");

                }else{
                    /*
                    * 库存充足,更新库存表
                    *
                    * */

                    chenkInventoryMapper.updateChenkInventory(list.get(i));
                    LOGGER.info("itemSkuCode: " + list.get(i).getItemSkuCode() + " 仓库库存充足,出库成功" );

                }
            }
        }

        /*
         * 更新出库单明细表状态信息，即出库数量
         * */
        productMapper.updateProduct(statusPush.getOrderCode());
        return true;
    }
}
