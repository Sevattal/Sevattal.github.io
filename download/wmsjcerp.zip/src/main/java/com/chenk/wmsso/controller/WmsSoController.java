package com.chenk.wmsso.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.chenk.util.JsonUtil;
import com.chenk.util.PrintPramUtil;
import com.chenk.util.SignatureUtil;
import com.chenk.wmsso.service.WmsSoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class WmsSoController {

    @Autowired
    private WmsSoService wmsSoService;

    private JsonUtil jsonUtil = new JsonUtil();
    private JSONObject jsonObject = new JSONObject();
    private JSONObject localJsonObject = new JSONObject();
    private SignatureUtil signatureUtil = new SignatureUtil();

    private static final org.slf4j.Logger LOGGER = (Logger) LoggerFactory.getLogger(WmsSoController.class);

    @ResponseBody
    @RequestMapping(value = "/wmsso",method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
    public String wmsso(@RequestParam(value="serviceType",required=false) String serviceType,
                        @RequestParam(value="sign",required = false) String sign,
                        @RequestParam(value="bizData",required = false) String bizData,
                        @RequestParam(value = "partnerID",required = false) String partnerID) {

        /*
         * 打印WmsSo Controller开始信息
         * */

        LOGGER.info("WmsSo Controller Start");


        /*
         * wmsso打印传来的信息
         * */
        PrintPramUtil printPramUtil = new PrintPramUtil(serviceType,sign,bizData,partnerID);

        /*
         * wmsso传来的数据，按理说需要配置签名（这边我没有配置）
         * */
        if (signatureUtil.isReal(serviceType,sign,bizData,partnerID)){

            LOGGER.info("数字签名验证成功");

        }else{

            LOGGER.info("数字签名验证失败,不允许同步");
            return "数字签名验证失败";
        }

        /*
         * 将bizData转换成jsonObject对象
         * */
        jsonObject= JSON.parseObject(bizData);


        /*
         * 处理Json数据
         * 由于原json格式报文有package关键字，本地实体类无法创建package对象需要在插入本地对象前将
         * package转换成本地对象ChenkPackage
         *
         * */
        LOGGER.info("WmsSo JsonObject Change LocalJsonObject Start");
        localJsonObject=jsonUtil.jsonChange(jsonObject);
        LOGGER.info("WmsSo JsonObject Change LocalJsonObject End");

        /*
         * 开始业务层操作，将状态信息更新到本地数据库中
         * */
        LOGGER.info("开始同步状态信息");
        boolean flag = wmsSoService.wmsso(localJsonObject);
        LOGGER.info("状态同步信息完毕");

        /*
         * 状态同步后，返回处理结果
         *
         * */
        LOGGER.info("返回状态同步处理结果");
        if (flag==true) {
            /*
             * 同步成功
             * */
            LOGGER.info(jsonUtil.getTrueJson());
            LOGGER.info("WmsSo Controller END");
            return jsonUtil.getTrueJson();

        }else {

            /*
             * 同步失败
             * */
            LOGGER.info(jsonUtil.getFalseJson());
            LOGGER.info("WmsSo Controller END");
            return jsonUtil.getFalseJson();
        }
    }

}
