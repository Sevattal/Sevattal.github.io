package com.chenk.wmsso.domain;

public class ChenkProduct {
    // orderCode 订单号
    private String orderCode;
    // itemCode 产品号
    private String itemSkuCode;
    // minQuantity 最小库存数
    private int minQuantity;
    // sumQuantity 全部数量
    private int sumQuantity;
    // loadedQuantity 已出库数量
    private int loadedQuantity;
    // unloadedQuantity 未出库数量
    private int unloadedQuantity;
    //unitPrice单价
    private double unitPrice;

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    public String getItemSkuCode() {
        return itemSkuCode;
    }

    public void setItemSkuCode(String itemSkuCode) {
        this.itemSkuCode = itemSkuCode;
    }

    public int getMinQuantity() {
        return minQuantity;
    }

    public void setMinQuantity(int minQuantity) {
        this.minQuantity = minQuantity;
    }

    public int getSumQuantity() {
        return sumQuantity;
    }

    public void setSumQuantity(int sumQuantity) {
        this.sumQuantity = sumQuantity;
    }

    public int getLoadedQuantity() {
        return loadedQuantity;
    }

    public void setLoadedQuantity(int loadedQuantity) {
        this.loadedQuantity = loadedQuantity;
    }

    public int getUnloadedQuantity() {
        return unloadedQuantity;
    }

    public void setUnloadedQuantity(int unloadedQuantity) {
        this.unloadedQuantity = unloadedQuantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    @Override
    public String toString() {
        return "ChenkProduct{" +
                "orderCode='" + orderCode + '\'' +
                ", itemSkuCode='" + itemSkuCode + '\'' +
                ", minQuantity=" + minQuantity +
                ", sumQuantity=" + sumQuantity +
                ", loadedQuantity=" + loadedQuantity +
                ", unloadedQuantity=" + unloadedQuantity +
                ", unitPrice=" + unitPrice +
                '}';
    }
}


