package com.chenk.wmsso.domain;

import java.util.List;

public class Products {
    private List<Product> product;

    public List<Product> getProduct() {
        return product;
    }

    public void setProduct(List<Product> product) {
        this.product = product;
    }
}
