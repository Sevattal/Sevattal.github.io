package com.chenk.wmsso.mapper;

import com.chenk.wmsso.domain.ChenkInventory;
import com.chenk.wmsso.domain.ChenkProduct;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("WmsSoChenkInventoryMapper")
@Mapper
public interface ChenkInventoryMapper {

    public int countChenkInventory(String itemSkuCode);

    public boolean updateChenkInventory(ChenkProduct chenkProduct);

    public ChenkInventory selectChenkInventory(String itemSkuCode);
}
