package com.chenk.wmsso.domain;

public class SnCodeList {
    private String snCode;

    public String getSnCode() {
        return snCode;
    }

    public void setSnCode(String snCode) {
        this.snCode = snCode;
    }
}
