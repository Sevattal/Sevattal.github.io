package com.chenk.wmsso.domain;

import java.util.List;

public class Invoices {
    private List<Invoices> invoices;

    public List<Invoices> getInvoices() {
        return invoices;
    }

    public void setInvoices(List<Invoices> invoices) {
        this.invoices = invoices;
    }
}
