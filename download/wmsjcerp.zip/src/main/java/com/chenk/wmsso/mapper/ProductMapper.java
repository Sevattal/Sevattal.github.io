package com.chenk.wmsso.mapper;


import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("WmsSoProductMapper")
@Mapper
public interface ProductMapper {

    /*更新出库单明细表状态*/
    public boolean updateProduct(String orderCode);
}
