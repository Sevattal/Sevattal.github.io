package com.chenk.wmsso.mapper;

import com.chenk.wmsso.domain.StatusPush;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/*
* @Repository("WmsSoStatusPush")解决不同包下，
* 有相同的Mapper接口报错的情况，不同的包名Repository名称要不同
* */
@Repository("WmsSoStatusPushMapper")
@Mapper
public interface StatusPushMapper {

    /*
    * 更新出库状态，完全出库
    * */
    public boolean updateStatusPush(String orderCode);

    /*
    * 查找是否有该出库单
    * */
    public int  countStatusPush(String orderCode);
}
