package com.chenk.wmsso.mapper;


import com.chenk.wmsso.domain.ChenkProduct;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("WmsSoChenkProductMapper")
@Mapper
public interface ChenkProductMapper {
    public List<ChenkProduct> selectChenkProduct(String orderCode);
}
