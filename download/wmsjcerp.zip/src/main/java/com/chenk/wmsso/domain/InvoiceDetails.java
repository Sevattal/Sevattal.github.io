package com.chenk.wmsso.domain;

import java.util.List;

public class InvoiceDetails {
    private List<InvoiceDetail> invoiceDetail;

    public List<InvoiceDetail> getInvoiceDetail() {
        return invoiceDetail;
    }

    public void setInvoiceDetail(List<InvoiceDetail> invoiceDetail) {
        this.invoiceDetail = invoiceDetail;
    }
}
