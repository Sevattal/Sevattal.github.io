package com.chenk.wmsso.domain;

import java.util.List;

public class Boxes {
    private List<Box> box;

    public List<Box> getBox() {
        return box;
    }

    public void setBox(List<Box> box) {
        this.box = box;
    }
}
