package com.chenk.wmsso.domain;

public class Package {
    private String packCode;
    private String packLogisticsProviderCode;
    private String warehouseCode;
    private String packShippingOrderNo;
    private double packWeight;
    private double packNetWeight;
    private double packGrossWeight;
    private double packVolume;
    private double packLength;
    private double packWidth;
    private double packHeight;
    private String consumablesCode;
    private String consumablesName;

    public String getPackCode() {
        return packCode;
    }

    public void setPackCode(String packCode) {
        this.packCode = packCode;
    }

    public String getPackLogisticsProviderCode() {
        return packLogisticsProviderCode;
    }

    public void setPackLogisticsProviderCode(String packLogisticsProviderCode) {
        this.packLogisticsProviderCode = packLogisticsProviderCode;
    }

    public String getWarehouseCode() {
        return warehouseCode;
    }

    public void setWarehouseCode(String warehouseCode) {
        this.warehouseCode = warehouseCode;
    }

    public String getPackShippingOrderNo() {
        return packShippingOrderNo;
    }

    public void setPackShippingOrderNo(String packShippingOrderNo) {
        this.packShippingOrderNo = packShippingOrderNo;
    }

    public double getPackWeight() {
        return packWeight;
    }

    public void setPackWeight(double packWeight) {
        this.packWeight = packWeight;
    }

    public double getPackNetWeight() {
        return packNetWeight;
    }

    public void setPackNetWeight(double packNetWeight) {
        this.packNetWeight = packNetWeight;
    }

    public double getPackGrossWeight() {
        return packGrossWeight;
    }

    public void setPackGrossWeight(double packGrossWeight) {
        this.packGrossWeight = packGrossWeight;
    }

    public double getPackVolume() {
        return packVolume;
    }

    public void setPackVolume(double packVolume) {
        this.packVolume = packVolume;
    }

    public double getPackLength() {
        return packLength;
    }

    public void setPackLength(double packLength) {
        this.packLength = packLength;
    }

    public double getPackWidth() {
        return packWidth;
    }

    public void setPackWidth(double packWidth) {
        this.packWidth = packWidth;
    }

    public double getPackHeight() {
        return packHeight;
    }

    public void setPackHeight(double packHeight) {
        this.packHeight = packHeight;
    }

    public String getConsumablesCode() {
        return consumablesCode;
    }

    public void setConsumablesCode(String consumablesCode) {
        this.consumablesCode = consumablesCode;
    }

    public String getConsumablesName() {
        return consumablesName;
    }

    public void setConsumablesName(String consumablesName) {
        this.consumablesName = consumablesName;
    }
}
