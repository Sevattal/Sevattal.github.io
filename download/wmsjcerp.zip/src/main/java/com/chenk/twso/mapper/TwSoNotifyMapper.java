package com.chenk.twso.mapper;

import com.best.javaSdk.twSoNotify.request.TwSoNotifyReq;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Repository("TwSoNotifyMapper")
@Mapper
public interface TwSoNotifyMapper {
    /*
    * 查询指定订单得信息
    * */
    public TwSoNotifyReq selectTwSoNotify(String orderCode);

    /*
     * 若同步成功，更新主表同步状态信息
     * */
    public boolean twsoOk(String orderCode);

    /*
    * 判断仓库是否是CRM电商仓库
    * */
    public int isCrmTwSoNotify(String orderCode);

}
