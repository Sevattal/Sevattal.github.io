package com.chenk.twso.mapper;

import com.best.javaSdk.twSoNotify.request.Receiver;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Repository("TwSoReceiverMapper")
@Mapper
public interface ReceiverMapper {

    /*
    * 按照订单查询获取收货人信息
    * */
    public Receiver selectReceiver(String orderCode);
}
