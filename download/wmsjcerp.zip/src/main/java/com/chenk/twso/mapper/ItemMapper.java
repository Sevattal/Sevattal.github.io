package com.chenk.twso.mapper;


import com.best.javaSdk.twSoNotify.request.Item;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("TwSoItemMapper")
@Mapper
public interface ItemMapper {

    /*
    * 查询指定出库单得Item信息
    * */
    public List<Item> selectItem(String orderCode);

}
