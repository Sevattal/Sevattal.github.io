package com.chenk.twso.service;

import com.alibaba.fastjson.JSONObject;

public interface TwSoService {


    public boolean syncTwSo(String orderCode);
}
