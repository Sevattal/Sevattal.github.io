package com.chenk.twso.mapper;


import com.best.javaSdk.twSoNotify.request.Sender;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Repository("TwSoSenderMapper")
@Mapper
public interface SenderMapper {

    /*
    * 按照订单号查询获取发件人信息
    * */
    public Sender selectSender(String orderCode);
}
