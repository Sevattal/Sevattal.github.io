package com.chenk.twso.service.Impl;

import com.best.javaSdk.twSoNotify.request.*;
import com.best.javaSdk.twSoNotify.response.TwSoNotifyRsp;
import com.chenk.twso.mapper.ItemMapper;
import com.chenk.twso.mapper.ReceiverMapper;
import com.chenk.twso.mapper.SenderMapper;
import com.chenk.twso.mapper.TwSoNotifyMapper;
import com.chenk.twso.service.TwSoService;
import com.chenk.util.BestPramUtil;
import com.chenk.util.ClientUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TwSoServiceImpl implements TwSoService {

    @Autowired
    private ItemMapper itemMapper;
    @Autowired
    private ReceiverMapper receiverMapper;
    @Autowired
    private SenderMapper senderMapper;
    @Autowired
    private TwSoNotifyMapper twSoNotifyMapper;

    private BestPramUtil bestPramUtil = new BestPramUtil();
    private TwSoNotifyReq Req = new TwSoNotifyReq();
    private TwSoNotifyRsp Rsp = new TwSoNotifyRsp();
    private ClientUtil clientUtil = new ClientUtil();
    private ItemList itemList = new ItemList();
    private List<Item> lists;
    private Sender sender = new Sender();
    private Receiver receiver = new Receiver();
    private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(TwSoServiceImpl.class);

    @Override
    public boolean syncTwSo(String orderCode) {
        /*
         * TwAsn Service 层开始信息提示
         * */
        LOGGER.info("TwAsn Service Start");

        /*
         * 判断是不是CRM电商仓库，若不是电商仓库直接返回false
         *
         * */
        if (twSoNotifyMapper.isCrmTwSoNotify(orderCode) != 31){
            LOGGER.info("该订单不是CRM电商仓库的订单，无法同步");
            return false;
        }

        /*
         * 获取订单信息
         * */
        Req = twSoNotifyMapper.selectTwSoNotify(orderCode);
        LOGGER.info("Req 出库单原数据 " + Req.toString());

        /*
         * 获取订单产品信息
         * */
        lists = itemMapper.selectItem(orderCode);

        /*
        *
        * 判断产品信息是否为空，若为空不同步
        * */
        if (lists.size() == 0){
            LOGGER.info("订单中没有产品信息,不允许同步");
            return false;
        }

        /*
        * 打印订单中产品信息
        * */
        LOGGER.info("订单中产品的原始信息");
        for (int i=0;i<lists.size();i++){
            LOGGER.info(lists.get(i).toString());
        }


        /*
        * 判断订单产品是否为多个，若为多个配置行号
        * */
         for (int i=0;i<lists.size();i++){
             lists.get(i).setLineNo(i+1);
             if (lists.get(i).getItemSkuCode().equalsIgnoreCase("") || lists.get(i).getItemSkuCode().equalsIgnoreCase("null") ||
             lists.get(i).getItemSkuCode().isEmpty()){
                 LOGGER.info("ItemSkuCode 为空不允许同步");
                 return false;
             }
             if (lists.get(i).getItemName().equalsIgnoreCase("")||lists.get(i).getItemName().equalsIgnoreCase("null") ||
             lists.get(i).getItemName().isEmpty()){
                 LOGGER.info("ItemName 为空不允许同步");
             }
         }

        itemList.setItem(lists);
        Req.setItemList(itemList);

        /*
         * 获取订单发送者信息
         * */
        sender = senderMapper.selectSender(orderCode);
        if (sender.getName().equalsIgnoreCase("null")||sender.getName().isEmpty()){
            sender.setName("Name None");
            LOGGER.info("Sender Name 的值为空,设置为Name None");
        }
        if (sender.getCity().equalsIgnoreCase("null")||sender.getCity().isEmpty()){
            sender.setCity("City None");
            LOGGER.info("City 的值为空,设置为City None");
        }
        if (sender.getAddress().equalsIgnoreCase("null")||sender.getAddress().isEmpty()){
            sender.setAddress("Address None");
            LOGGER.info("Address 的值为空,设置为Address None");
        }
        if (sender.getContactName().equalsIgnoreCase("null")||sender.getContactName().isEmpty()){
            sender.setContactName("ContactName None");
            LOGGER.info("ContactName 的值为空,设置为ContactName None");
        }
        if (sender.getDistrict().equalsIgnoreCase("null")||sender.getDistrict().isEmpty()){
            sender.setDistrict("District None");
            LOGGER.info("District 的值为空,设置为District None");
        }
        if (sender.getPhone().equalsIgnoreCase("null") || sender.getPhone().isEmpty()){
            sender.setPhone("Phone None");
            LOGGER.info("Phone 的值为空,设置为Phone None");
        }
        if (sender.getProvince().equalsIgnoreCase("null")||sender.getProvince().isEmpty()){
            sender.setProvince("Province None");
            LOGGER.info("Province 的值为空,设置为Province None");
        }

        LOGGER.info("Sender 发送者更改后: "+sender.toString());
        Req.setSender(sender);


        /*
         * 获取订单接收者信息,由于receiver接收者信息不全，传入假信息
         * */
        receiver = receiverMapper.selectReceiver(orderCode);
        if (receiver.getName().equalsIgnoreCase("null")|| receiver.getName().isEmpty()){
            receiver.setName("Name None");
            LOGGER.info("Receiver Name 的值为空,设置为Name None");
        }
        if (receiver.getCity().equalsIgnoreCase("null")|| receiver.getCity().isEmpty()) {
            receiver.setCity("City None");
            LOGGER.info("City 的值为空,设置为City None");
        }
        if (receiver.getAddress().equalsIgnoreCase("null")|| receiver.getAddress().isEmpty()) {
            receiver.setAddress("Address None");
            LOGGER.info("Address 的值为空,设置为Address None");
        }
        if (receiver.getDistrict().equalsIgnoreCase("null")|| receiver.getDistrict().isEmpty()) {
            receiver.setDistrict("District None");
            LOGGER.info("District 的值为空,设置为District None");
        }
        if (receiver.getProvince().equalsIgnoreCase("null")||receiver.getProvince().isEmpty()) {
            receiver.setProvince("Province None");
            LOGGER.info("Province 的值为空,设置为Province None");
        }
        if (receiver.getPhone().equalsIgnoreCase("null")||receiver.getPhone().isEmpty()) {
            receiver.setPhone("Phone None");
            LOGGER.info("Phone 的值为空,设置为Phone None");
        }
        if (receiver.getContactName().equalsIgnoreCase("null")||receiver.getContactName().isEmpty()) {
            receiver.setContactName("ContactName None");
            LOGGER.info("ContactName 的值为空,设置为ContactName None");
        }
        LOGGER.info("Receiver 接收者更改后: " + receiver.toString());
        Req.setReceiver(receiver);

        /*
         * 配置百世仓配入库接口所必须参数参数
         * */
        Req.setCustomerCode(bestPramUtil.getCustomerCode());
        Req.setWarehouseCode(bestPramUtil.getWareHouseCode());
        Req.setProjectCode(bestPramUtil.getProjectCode());

        Req.setOperationFlag(bestPramUtil.getTwasnoperationFlag());
        Req.setActionType(bestPramUtil.getTwsoactionType());
        Req.setOperationTypeCode(bestPramUtil.getTwsooperationTypeCode());

        /*
         * 传送json数据给百世
         * */
        Rsp = clientUtil.getClient().executed(Req);

        if (Rsp.getResult() == true){

            LOGGER.info("orderCode: " + orderCode + " 同步成功");
            return true;

        }else{

            /*
             * 输出错误结果
             * */
            LOGGER.info("orderCode: " + orderCode + " 同步失败,百世返回报错如下:");
            LOGGER.info("ErrorCode: "+Rsp.getErrorCode());
            LOGGER.info("ErrorDescription: "+Rsp.getErrorDescription());
            LOGGER.info("Note: "+Rsp.getNote());
            return false;
        }
    }
}
