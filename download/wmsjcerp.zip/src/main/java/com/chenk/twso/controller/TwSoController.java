package com.chenk.twso.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.chenk.twso.service.TwSoService;
import com.chenk.util.ChenkJsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TwSoController {

    @Autowired
    private TwSoService twSoService;


    private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(TwSoController.class);

    @RequestMapping("twso")
    public String twso(@RequestBody String orderCode){
        /*
         * TwSo Controller 开始信息提示
         * */
        LOGGER.info("TwSo Controller Start");
        LOGGER.info("Print orderCode: " + orderCode);


        /*
         * 将Json数据转换成字符串
         * */
        JSONObject jsonObject = JSON.parseObject(orderCode);
        LOGGER.info("orderCode: " + jsonObject.get("orderCode"));
        String order = jsonObject.getString("orderCode");

        /*
         * 若传入的orderCode为空，则直接返回错误
         * */
        if (order.isEmpty()){
            return ChenkJsonUtil.getJsonResultFalse().toJSONString();
        }

        /*
         * 若orderCode不为空，则开始执行service
         * */
        boolean flag = twSoService.syncTwSo(order);

        /*
         * 输出service结果，即数据同步结果
         * */
        if (flag == true){
            LOGGER.info("orderCode "+order+" is sync Successfully");
            return ChenkJsonUtil.getJsonResultTrue().toJSONString();
        }else {
            LOGGER.info("orderCode "+order+" is sync Failure");
            return ChenkJsonUtil.getJsonResultFalse().toJSONString();
        }
    }

}
