package com.chenk.test;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
public class controller {

    /*
    * @RequestMapping不写method,则GET和POST方法都支持
    *
    * */
    @RequestMapping(value = "/",produces = MediaType.APPLICATION_JSON_VALUE)
    public String callmain(@RequestBody String test)
    {

        System.out.println("HELLO WORLD" +test);
        return "HELLO WORLD";
    }

    @PostMapping(value = "/doSth",produces = MediaType.APPLICATION_JSON_VALUE)
    public String doSth(@RequestBody String inputJson) {

        System.out.println(inputJson);
        return inputJson;

    }

}
