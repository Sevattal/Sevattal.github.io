package com.chenk;


import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;


/*
* SpringBootApplication是Spring的启动依赖注解
* EnableScheduling是SpringBoot的启动定时任务注解
* EnableTransactionManagement 启动事务注解，之后在对应的service实现类的方法上添加Transactional注解
* chenk的平台可以去调用第三方接口，所以可以不适用Scheduling去定时同步计划
* */

/*
* Scheduled启动需要添加@EnableScheduling注解，才能启动别的包下的Scheduled程序，
* 当然也需要在@SpringBootApplication中加载扫描包地址scanBaseBackages
*
* */


@SpringBootApplication(scanBasePackages =
        {"com.chenk.wmsasn.controller", "com.chenk.wmsasn.service",
        "com.chenk.wmsso.controller","com.chenk.wmsso.service",
        "com.chenk.wmssku.controller","com.chenk.wmssku.service","com.chenk.wmssku.scheduler",
        "com.chenk.twasn.controller","com.chenk.twasn.service",
        "com.chenk.twso.controller","com.chenk.twso.service",
        "com.chenk.twcancel.controller","com.chenk.twcancel.service",
        "com.chenk.test"})
@EnableTransactionManagement
//@EnableScheduling
public class ChenkApplication  extends SpringBootServletInitializer {

    /*
    * SpringBoot的Logger配置，需要以下两个包
    * import org.slf4j.LoggerFactory;
    * import org.slf4j.Logger;
    * 最好不同业务或者不同类的加载的类名不同，即每个不同类加载本类的Logger日志
    * */
    /*
    * 在启动类当中加上extends SpringBootServletInitializer并重写configure方法，这是为了打包springboot项目用的。
    * */
    private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(ChenkApplication.class);

    /*
    * SpringBoot启动入库
    * */
    public static void main(String[] args) {
        SpringApplication.run(ChenkApplication.class, args);
        LOGGER.info("==========print log===========");

    }

    /*
    * 为了打包springboot项目
    * */
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(this.getClass());
    }


}
