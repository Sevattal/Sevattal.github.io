package com.chenk.util;

import com.alibaba.fastjson.JSONObject;

public class ChenkJsonUtil {

    private static JSONObject jsonResultFalse = new JSONObject();
    private static JSONObject jsonResultTrue = new JSONObject();
    static{
        jsonResultTrue.put("msg","同步成功");
        jsonResultTrue.put("code","0");
        jsonResultTrue.put("data","True");
        jsonResultFalse.put("msg","同步失败");
        jsonResultFalse.put("code","1");
        jsonResultFalse.put("data","False");
    }

    public static JSONObject getJsonResultFalse() {
        return jsonResultFalse;
    }

    public static void setJsonResultFalse(JSONObject jsonResultFalse) {
        ChenkJsonUtil.jsonResultFalse = jsonResultFalse;
    }

    public static JSONObject getJsonResultTrue() {
        return jsonResultTrue;
    }

    public static void setJsonResultTrue(JSONObject jsonResultTrue) {
        ChenkJsonUtil.jsonResultTrue = jsonResultTrue;
    }
}
