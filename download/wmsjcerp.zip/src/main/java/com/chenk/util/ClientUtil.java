package com.chenk.util;

import com.best.javaSdk.Client;
import com.best.javaSdk.wmsSkuNotify.request.WmsSkuNotifyReq;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/*
* ClientUtil的作用是获取best接口的Client客户端，对Client客户端预处理传参数
*
* */

public class ClientUtil {


    private static BestPramUtil bestPramUtil = new BestPramUtil();
    private static Client client;
    private static WmsSkuNotifyReq Req = new WmsSkuNotifyReq();
    private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(ClientUtil.class);

    static {
        client = new Client(bestPramUtil.getUrl(),bestPramUtil.getPartnerId(),
                bestPramUtil.getPartnerKey(), bestPramUtil.getFormat());

        Req.setProviderCode(bestPramUtil.getProviderCode());
    }

    public static Client getClient() {
        return client;
    }

    public static void setClient(Client client) {
        ClientUtil.client = client;
    }

    public static WmsSkuNotifyReq getReq() {
        return Req;
    }
}

