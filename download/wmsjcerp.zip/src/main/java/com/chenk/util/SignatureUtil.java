package com.chenk.util;

import com.best.javaSdk.Param;
import com.best.javaSdk.Sign;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
* SignatureUtil,签名判断工具类,判断best传来的签名是否正确
*
* */
public class SignatureUtil {

    private  Param param = new Param();
    private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(SignatureUtil.class);
    public boolean isReal(String serviceType,String sign,String bizData,String partnerID){
        /*
        * 配置param参数
        * */
        LOGGER.info("开始配置签名参数,Param");
        param.setServiceType(serviceType);
        param.setSign(sign);
        param.setBizData(bizData);
        param.setPartnerID(partnerID);
        param.setPartnerKey(BestPramUtil.getPartnerKey());

        /*
        * 判断传入的签名是否正确
        * */
        System.out.println(Sign.makeSign(param));
        if (Sign.makeSign(param).equals(sign)) {
            LOGGER.info("百世传递来的签名正确");
            return true;
        }else {
            LOGGER.info("百世传递来的签名错误");
            return false;
        }
    }
}
