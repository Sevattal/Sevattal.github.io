package com.chenk.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.Properties;

/*
* best接口所需要的参数，从best.properties文件中获取到
* 若要知道这些参数的含义，请直接到best.properties文件中查看
*
* */

public class BestPramUtil {
    private static String url;
    private static String partnerKey;
    private static String partnerId;
    private static String format;
    private static String providerCode;
    private static String customerCode;
    private static String wareHouseCode;
    private static String projectCode;
    private static String skuactionType;
    private static int skuSize;

    private static String twasnactionType;
    private static String twasnoperationFlag;
    private static String twasnoperationTypeCode;

    private static String twsoactionType;
    private static String twasooperationFlag;
    private static String twsooperationTypeCode;

    private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(BestPramUtil.class);
    private static Properties properties = new Properties();
    private static InputStream inputStream = BestPramUtil.class.getResourceAsStream("/best.properties");
    static{
        try {
            properties.load(inputStream);
            /*
            * Client必要参数配置
            * */
            url = properties.getProperty("url");
            partnerId = properties.getProperty("partnerId");
            partnerKey = properties.getProperty("partnerKey");
            format = properties.getProperty("format");
            providerCode = properties.getProperty("providerCode");
            customerCode = properties.getProperty("customerCode");
            wareHouseCode = properties.getProperty("wareHouseCode");
            projectCode = properties.getProperty("projectCode");

            /*
            * sku同步必要参数配置
            * */
            skuactionType = properties.getProperty("skuactionType");
            skuSize = Integer.parseInt(properties.getProperty("skuSize"));

            /*
            * twasn必要参数配置
            * */
            twasnactionType = properties.getProperty("twasnactionType");
            twasnoperationFlag = properties.getProperty("twasnoperationFlag");
            twasnoperationTypeCode = properties.getProperty("twasnoperationTypeCode");

            /*
            * twso必要参数配置
            * */
            twsoactionType =properties.getProperty("twsoactionType");
            twasooperationFlag=properties.getProperty("twasooperationFlag");
            twsooperationTypeCode=properties.getProperty("twsooperationTypeCode");

        }catch (Exception e){
            LOGGER.error(e.getMessage());
            LOGGER.error(e.getCause().toString());
        }
    }

    public static String getUrl() {
        return url;
    }

    public static void setUrl(String url) {
        BestPramUtil.url = url;
    }

    public static String getPartnerKey() {
        return partnerKey;
    }

    public static void setPartnerKey(String partnerKey) {
        BestPramUtil.partnerKey = partnerKey;
    }

    public static String getPartnerId() {
        return partnerId;
    }

    public static void setPartnerId(String partnerId) {
        BestPramUtil.partnerId = partnerId;
    }

    public static String getFormat() {
        return format;
    }

    public static void setFormat(String format) {
        BestPramUtil.format = format;
    }

    public static String getProviderCode() {
        return providerCode;
    }

    public static void setProviderCode(String providerCode) {
        BestPramUtil.providerCode = providerCode;
    }

    public static String getCustomerCode() {
        return customerCode;
    }

    public static void setCustomerCode(String customerCode) {
        BestPramUtil.customerCode = customerCode;
    }

    public static String getWareHouseCode() {
        return wareHouseCode;
    }

    public static void setWareHouseCode(String wareHouseCode) {
        BestPramUtil.wareHouseCode = wareHouseCode;
    }

    public static String getProjectCode() {
        return projectCode;
    }

    public static void setProjectCode(String projectCode) {
        BestPramUtil.projectCode = projectCode;
    }

    public static String getSkuactionType() {
        return skuactionType;
    }

    public static void setSkuactionType(String skuactionType) {
        BestPramUtil.skuactionType = skuactionType;
    }

    public static int getSkuSize() {
        return skuSize;
    }

    public static void setSkuSize(int skuSize) {
        BestPramUtil.skuSize = skuSize;
    }

    public static String getTwasnactionType() {
        return twasnactionType;
    }

    public static void setTwasnactionType(String twasnactionType) {
        BestPramUtil.twasnactionType = twasnactionType;
    }

    public static String getTwasnoperationFlag() {
        return twasnoperationFlag;
    }

    public static void setTwasnoperationFlag(String twasnoperationFlag) {
        BestPramUtil.twasnoperationFlag = twasnoperationFlag;
    }

    public static String getTwasnoperationTypeCode() {
        return twasnoperationTypeCode;
    }

    public static void setTwasnoperationTypeCode(String twasnoperationTypeCode) {
        BestPramUtil.twasnoperationTypeCode = twasnoperationTypeCode;
    }

    public static String getTwsoactionType() {
        return twsoactionType;
    }

    public static void setTwsoactionType(String twsoactionType) {
        BestPramUtil.twsoactionType = twsoactionType;
    }

    public static String getTwasooperationFlag() {
        return twasooperationFlag;
    }

    public static void setTwasooperationFlag(String twasooperationFlag) {
        BestPramUtil.twasooperationFlag = twasooperationFlag;
    }

    public static String getTwsooperationTypeCode() {
        return twsooperationTypeCode;
    }

    public static void setTwsooperationTypeCode(String twsooperationTypeCode) {
        BestPramUtil.twsooperationTypeCode = twsooperationTypeCode;
    }
}
