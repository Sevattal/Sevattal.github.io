package com.chenk.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
* 初始化Json数据格式的返回值，分别是true和false
*
* */

public class JsonUtil {

    private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(JsonUtil.class);
    private static JSONObject jsonResultFalse = new JSONObject();
    private static JSONObject jsonResultTrue = new JSONObject();
    private JSONObject localJsonObject = new JSONObject();
    private String str;

    static {
        jsonResultTrue.put("result", true);
        jsonResultTrue.put("note", "入库状态信息推送成功");
        jsonResultFalse.put("result", false);
        jsonResultFalse.put("node", "入库状态信息推送失败");
        jsonResultFalse.put("errorCode", ".....");
        jsonResultFalse.put("errorDescription", ".....");
    }

    public JSONObject jsonChange(JSONObject jsonObject){

        /*
         * 由于原json格式报文有package关键字，本地实体类无法创建package对象需要在插入本地对象前将
         * package转换成本地对象ChenkPackage
         * */
        LOGGER.info("WmsAsn JsonObject Change LocalJsonObject Start");
        str = jsonObject.toJSONString();
        str = str.replaceFirst("\"package\"","\"ChenkPackage\"");
        LOGGER.info("Out Print str: "+str);
        localJsonObject = JSON.parseObject(str);
        return  localJsonObject;
    }

    public String getTrueJson(){

        return jsonResultTrue.toJSONString();
    }

    public String getFalseJson(){

        return  jsonResultFalse.toJSONString();
    }


}
