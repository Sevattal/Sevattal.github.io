package com.chenk.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PrintPramUtil {


    private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(PrintPramUtil.class);
    /*
    * 只做打印POST传来的参数
    *
    * */
    public PrintPramUtil(String serviceType,String sign,String bizData,String partnerID){
        LOGGER.info("----------serviceType-----------");
        LOGGER.info(serviceType);
        LOGGER.info("----------sign---------------");
        LOGGER.info(sign);
        LOGGER.info("-----------bizData---------------");
        LOGGER.info(bizData);
        LOGGER.info("--------------partnerID------------");
        LOGGER.info(partnerID);
    }
}
