package com.chenk.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class RandomUtil {
    private String rand;
    private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(RandomUtil.class);
    /*
    * 该类生成的是一个随机的值，格式为：6位年月日+五位数字
    * */
    public String getRand() {
        SimpleDateFormat simpleDateFormat;
        simpleDateFormat=new SimpleDateFormat("yyyyMMdd");
        String date=simpleDateFormat.format(new Date());
        Random random=new Random();
        int rannum= (int)(random.nextDouble()*(99999-10000 + 1))+ 10000;
        String rand=date+rannum;
        LOGGER.info("RandomUtil Get Rand: "+rand);
        return rand;
    }
}
