package com.chenk.wmssku.scheduler;

import com.chenk.wmssku.service.WmsSkuService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

@Component
@Transactional
public class WmsSkuScheduler {

    @Autowired
    private WmsSkuService wmsSkuService;


    private static final org.slf4j.Logger LOGGER = (Logger) LoggerFactory.getLogger(WmsSkuScheduler.class);
    /*
     * 现在配置的是每3分钟执行一次, 1000*60*3
     * */
    @Scheduled(fixedRate = 5000)
    public void autoSyncSku(){
        /*
        * Scheduled 开始信息打印
        * */
        LOGGER.info("Auto Sync Sku Start");
        LOGGER.info("System TimeStamp: " + new Random().nextLong()
                + new SimpleDateFormat("HH:mm:ss").format(new Date()));
        /*
        * 开始同步信息
        * */
        boolean flag = wmsSkuService.syncSku();
        if (flag){
            LOGGER.info("Sku Sync Successfully");
        }else {
            LOGGER.info("Sku Sync Failure");
        }

    }

}
