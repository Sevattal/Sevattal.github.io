package com.chenk.wmssku.service;


public interface WmsSkuService {

    //同步全部未同步的数据
    public boolean syncSku();

    //同步单条产品数据
    public boolean syncSku(String itemSkuItem);

}
