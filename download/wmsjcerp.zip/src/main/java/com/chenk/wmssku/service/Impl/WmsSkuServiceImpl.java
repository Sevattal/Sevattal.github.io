package com.chenk.wmssku.service.Impl;

import com.best.javaSdk.wmsSkuNotify.request.Product;
import com.best.javaSdk.wmsSkuNotify.request.Products;
import com.best.javaSdk.wmsSkuNotify.request.WmsSkuNotifyReq;
import com.best.javaSdk.wmsSkuNotify.response.WmsSkuNotifyRsp;
import com.chenk.util.BestPramUtil;
import com.chenk.util.ClientUtil;
import com.chenk.util.RandomUtil;
import com.chenk.wmssku.mapper.ProductMapper;
import com.chenk.wmssku.service.WmsSkuService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class WmsSkuServiceImpl implements WmsSkuService {

    /*
    * 注入持久层
    * */
    @Autowired
    private ProductMapper productMapper;

    private ClientUtil client = new ClientUtil();
    private WmsSkuNotifyReq Req;
    private WmsSkuNotifyRsp Rsp = new WmsSkuNotifyRsp();
    private Products products = new Products();
    private List<Product> lists = new ArrayList<Product>();
    private List<Product> subLists = new ArrayList<Product>();
    private RandomUtil randomUtil = new RandomUtil();

    private static final org.slf4j.Logger LOGGER = (Logger) LoggerFactory.getLogger(WmsSkuServiceImpl.class);



    /*
    * 判定该未同步的产品数据方式为:判断产品信息表skf724字段的值 skf724 = 0 or skf724 is  null
    * 判断操作已在wmssku/ProductMapper.xml文件中sql语句已配置好
    *
    * 完成将所有未同步的产品数据同步到best,一次同步数据的量为BestPramUtil.getSkuSize()，
    * 即best.properties文件中配置的skuSize的值。
    *
    * */
    @Override
    public boolean syncSku() {
        /*
        * 输出服务信息
        * */
        LOGGER.info("WmsSku Service Start");
        /*
        * 获取Req对象
        * */
        Req = client.getReq();
        LOGGER.info("获取Req对象成功");
        /*
        * 获取所有没有同步的产品信息
        * */
        lists = productMapper.selectNoSkuProduct();
        LOGGER.info("获取本地产品数据成功");

        /*
        * 循环判断数据是否有空，以下判断的值都为百世接口必填数据
        *
        * */
        LOGGER.info("开始判断数据是否符合百世接口要求,以下处理为判断数据是否为百世接口必填数据");
        LOGGER.info("日志只记录更改数据信息,若原数据满足百世接口数据,则不进行更改");
        for (int i=0;i<lists.size();i++){

            /*
            * 若itemSkuCode为空，那么就将一个随机的ItemSkuCode数据传输过去
            * 该数据值为：ItemSkuCode+6位年于日+5位数字
            * */
            if (lists.get(i).getItemSkuCode().equalsIgnoreCase("null") || lists.get(i).getItemSkuCode().equalsIgnoreCase("") || lists.get(i).getItemSkuCode().isEmpty()){
                String str = "ItemSkuCode" + randomUtil.getRand();
                lists.get(i).setItemName(str);
                LOGGER.info("ItemSkuCode 的值为空,设置其值为: "+ str);
            }
            /*
            * 若ItemName的名字位空，将设置位ItemName is None传送过去
            * */
            if (lists.get(i).getItemName().equalsIgnoreCase("null")|| lists.get(i).getItemName().equalsIgnoreCase("") || lists.get(i).getItemName().isEmpty()){
                lists.get(i).setItemName("ItemName is None");
                LOGGER.info("ItemName 的值为空,设置其值为: ItemName is None");
            }
            /*
            * ActionType为必传值，若为空的话，或者其值不为ADD-OW
            * 则将其值设置成ADD-OW,否则该数据无法传输
            * */
            if (lists.get(i).getActionType().equalsIgnoreCase("null") || lists.get(i).getActionType().equalsIgnoreCase("")
                    || lists.get(i).getActionType().isEmpty() || lists.get(i).getActionType().equals("ADD-OW") != true){
                lists.get(i).setItemName(BestPramUtil.getSkuactionType());
                LOGGER.info("ActionType 值不正确,以修改为正确值: " + BestPramUtil.getSkuactionType());
            }
        }

        /*
        * 开始分批循环将数据传给百世接口
        *
        * */
        LOGGER.info("开始分批将数据传入百世接口");
        for (int j = 0,i =0; i<lists.size();i=i+ BestPramUtil.getSkuSize()) {
            /*
            * 若lists为0则跳出循环，说明没有需要同步的数据
            * */
            LOGGER.info("开始判断是否拥有数据,若没有数据则直接结束同步");
            if (lists.size()==0){
                LOGGER.info("没有更多新的数据可以同步给百世,结束同步产品信息");
                break;
            }

            /*
             * 判断获取的lists的区间，
             * 若大于则跳出循环
             * 若小于则判断加上偏移变量BestPramUtil.getSkuSize()后是否大于lists区间
             * 若大于则将lists.size()赋值给j
             * 若小于则将j加上偏移变量BestPramUtil.getSkuSize()
             * */
            LOGGER.info("开始分配数据传输数据的List区间");
            if (i <= lists.size()) {
                LOGGER.info("当前起始数据值小于最大未同步数据,进行下一步判断");
                if (i + BestPramUtil.getSkuSize() <= lists.size()) {
                    LOGGER.info("当前起始数据值 + 步进值 " + BestPramUtil.getSkuSize() +" 小于最大未同步数据值");
                    j = i + BestPramUtil.getSkuSize();
                    LOGGER.info("当前区间范围为: " + i + "~" + j);
                } else {
                    LOGGER.info("当前起始数据值 + 步进值 " + BestPramUtil.getSkuSize() +" 大于或者等于最大未同步数据值");
                    j = lists.size();
                    LOGGER.info("当前区间范围为: " + i + "~" + j);
                }
            } else {
                LOGGER.info("当前起始数据值大于最大未同步数据,即没有更多数据可以同步,结束产品信息同步");
                break;
            }

            /*
            * 给subLists赋值，即赋值lists中某一区间范围
            * */
            LOGGER.info("开始产品数据信息同步,同步范围为: " + i +"~" + j);
            subLists=lists.subList(i,j);
            LOGGER.info("配置区间List对象subLists,subList获取的值如下");
            LOGGER.info(subLists.toString());

            /*
            * 配置Products，产品列表数据
            * */
            LOGGER.info("将subLists对象数据,赋值给Products对象中");
            products.setProduct(subLists);
            LOGGER.info("配置Products对象成功");
            /*
            * 发送请求，将JSON数据到百世的服务器
            * */
            LOGGER.info("使用百世Client将产品信息数据传给百世");
            Req.setProducts(products);
            Rsp = client.getClient().executed(Req);

            /*
            * 若这一批数据更新成功，则更新本地产品表的同步状态
            * */
            if (Rsp.getResult()){
                LOGGER.info("批次: " + i + " 同步成功");
                LOGGER.info("开始更新该批次的主表的同步状态");
                for (int x = 0; j < subLists.size(); x++) {
                    productMapper.skuOk(subLists.get(x).getItemSkuCode());
                }
            } else {
                LOGGER.info("批次: " + i + " 同步失败");
                LOGGER.info("打印百世接口返回的错误信息");
                LOGGER.info("Rsp Errors: "+Rsp.getErrors());
                LOGGER.info("Rsp Note: " + Rsp.getNote());
                LOGGER.info("Slicing: " + i +  " is Failure");
            }
        }

        /*
        * 返回同步结果,由于能力有限我就只获取最后一次的同步状态，来判断是否同步成功
        * */
        if (Rsp.getResult()) {
            LOGGER.info("WmsSku Service Successfully");
            return true;
        }else {
            LOGGER.info("WmsSku Service Failure");
            return false;
        }
    }




    /*
    * 同步指定的产品信息,设计问题该service服务用不到
    *
    * */

    @Override
    @Transactional
    public boolean syncSku(String itemSkuCode) {
        /*
         * 输出服务信息
         * */
        LOGGER.info("WmsSku Service Start");
        Req = client.getReq();
        LOGGER.info("获取Req对象成功");

        /*
        * 判断指定的产品是否在产品信息表中存在
        * */
        if (productMapper.countProduct(itemSkuCode) == 0){
            LOGGER.info("传入的产品编号在数据库中不存在");
            return false;
        }

        LOGGER.info("获取对应itemSkuCode的产品编号的产品信息");
        Product product = productMapper.selectProduct(itemSkuCode);
        LOGGER.info("打印原本获取到的产品信息 "+product.toString());



        /*
        * 判断数据是否有必填值的错误
        * 由于该段是传入itemSkuCode所以itemSkuCode就不需要去判断了
        * */
        if (product.getItemName().isEmpty() || product.getItemName().equalsIgnoreCase("") ||
        product.getItemName().equalsIgnoreCase("null")){
            product.setItemName("ItemName is None");
            LOGGER.info("ItemName 的值为空,设置其值为: ItemName is None");
        }

        if (product.getActionType().equals("ADD-OW") != true || product.getActionType().isEmpty() ||
                product.getActionType().equalsIgnoreCase("") || product.getActionType().equalsIgnoreCase("null")){
            product.setItemName(BestPramUtil.getSkuactionType());
            LOGGER.info("ActionType 值不正确,以修改为正确值: " + BestPramUtil.getSkuactionType());
        }

        LOGGER.info("打印经过判断更改后的产品信息 "+product.toString());


        /*
         * 配置Products，产品列表数据
         * */
        lists.add(product);
        products.setProduct(lists);

        /*
         * 发送请求，将JSON数据到百世的服务器
         * */
        LOGGER.info("使用百世Client将产品信息数据传给百世");
        Req.setProducts(products);
        Rsp = client.getClient().executed(Req);

        /*
         * 若数据更新成功，则更新本地产品表的同步状态
         * */
        if (Rsp.getResult()){

            LOGGER.info("itemSkuCode: " + itemSkuCode + " 同步成功");
            LOGGER.info("itemSkuCode: " + itemSkuCode + " 开始更新同步状态");
            productMapper.skuOk(itemSkuCode);
            LOGGER.info("itemSkuCode: " + itemSkuCode + " 同步状态更新成功");

        } else {

            LOGGER.info("打印百世接口返回的错误信息");
            LOGGER.info("Rsp Errors: "+Rsp.getErrors());
            LOGGER.info("Rsp Note: " + Rsp.getNote());
            LOGGER.info("Failure");
        }

        /*
         * 返回同步结果
         *
         * */
        if (Rsp.getResult()) {
            LOGGER.info("同步成功");
            LOGGER.info("WmsSku Service Successfully");
            return true;
        }else {
            LOGGER.info("同步失败");
            LOGGER.info("WmsSku Service Failure");
            return false;
        }
    }



}
