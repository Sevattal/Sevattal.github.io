package com.chenk.wmssku.controller;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.chenk.util.ChenkJsonUtil;
import com.chenk.wmssku.service.WmsSkuService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WmsSkuController {

    @Autowired
    private WmsSkuService wmsSkuService;

    private static final org.slf4j.Logger LOGGER = (Logger) LoggerFactory.getLogger(WmsSkuController.class);


    /*
    * value="status" 表示该参数名为status，即url形式为：127.0.0.1:8081/chenk/wmssku?status=ok
    * 就是?号后的参数
    * 其中端口号和chenk路径 为application.properties中配置好的路径和端口
    * required=false 表示该参数是否必须传值
    * defaultValue 此参数的默认值，可以不写
    * 若要接收多个参数，以下为范例，即每个参数定义完以逗号隔开
    * @RequestParam(value="status",required=false,defaultValue="null") String status,
    * @RequestParam(value="test",required=false,defaultValue="null") String test
    *
    * */

    /*
    * wmsskuall为同步数据库中所有数据，list分组每组有100个Product一批，同步给best
    * http://127.0.0.1:8081/chenk/skuAllProduct?status=ok
    *
    * */

    @RequestMapping("/wmsskuall")
    public String wmsskuall() {

        /*
        * 提示Controller开始，
        * 并显示传入的skuStatus参数
        *
        * */
        LOGGER.info("WmsSkuAll Controller Start");

        /*
        * 若参数传输正确，就开始同步数据
        * */
        boolean flag = wmsSkuService.syncSku();

        /*
         * 返回同步数据结果信息
         * */
        if (flag){

            LOGGER.info("Sku Sync Successfully");
            return ChenkJsonUtil.getJsonResultTrue().toJSONString();

           }else {

            LOGGER.info("Sku Sync Failure");
            return ChenkJsonUtil.getJsonResultFalse().toJSONString();

        }

    }

    /*
    * 同步单条产品信息,由于平台设计问题该代码不能用在新增当中,
    * 只能使用在更新产品信息中
    * */
    @RequestMapping(value = "wmsskuone")
    public String wmssku(@RequestBody String itemSkuCode){
        /*
         * 提示Controller开始，
         * 并显示传入的itemSkuCode参数
         *
         * */
        LOGGER.info("WmsSkuOne Controller Start");
        LOGGER.info("Print itemSkuCode: " + itemSkuCode);

        /*
        * 将传入的json数据转换成对应的产品编号
        * */
        JSONObject jsonObject = JSON.parseObject(itemSkuCode);
        LOGGER.info("itemSkuCode: " + jsonObject.get("itemSkuCode"));
        String item = jsonObject.getString("itemSkuCode");

        /*
        * 判断itemSkuCode是否为空，若为空不进行同步
        * */
        if (item.isEmpty()){
            return ChenkJsonUtil.getJsonResultFalse().toJSONString();
        }

        /*
         * 若参数传输正确，就开始同步数据
         * */
        boolean flag = wmsSkuService.syncSku(item);

        /*
         * 返回同步数据结果信息
         * */
        if (flag){
            return ChenkJsonUtil.getJsonResultTrue().toJSONString();
        }else {
            return ChenkJsonUtil.getJsonResultFalse().toJSONString();
        }
    }
}
