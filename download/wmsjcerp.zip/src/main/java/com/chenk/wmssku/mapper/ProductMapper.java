package com.chenk.wmssku.mapper;

import com.best.javaSdk.wmsSkuNotify.request.Product;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository("WmsSkuProductMapper")
public interface ProductMapper {

    //查询所有Sku信息

    public List<Product> selectAllProduct();

    //插入所需同步信息单条

    public List<Product> selectNoSkuProduct();

    //更新同步状态
    public boolean skuOk(String itemSkuCode);

    //查询指定的产品信息
    public Product selectProduct(String itemSkuCode);

    //查询指定的产品是否存在
    public int countProduct(String itemSkuCode);

}
