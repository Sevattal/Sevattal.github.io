package com.chenk.wmsasn.domain;

import java.util.List;

public class Batchs {
    private List<Batch> batch;

    public List<Batch> getBatch() {
        return batch;
    }

    public void setBatch(List<Batch> batch) {
        this.batch = batch;
    }
}
