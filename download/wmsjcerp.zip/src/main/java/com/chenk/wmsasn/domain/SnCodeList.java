package com.chenk.wmsasn.domain;

import java.util.List;

public class SnCodeList {
    private List<String> snCode;

    public List<String> getSnCode() {
        return snCode;
    }

    public void setSnCode(List<String> snCode) {
        this.snCode = snCode;
    }

    @Override
    public String toString() {
        return "snCodeList{" +
                "snCode=" + snCode +
                '}';
    }
}
