package com.chenk.wmsasn.mapper;


import com.chenk.wmsasn.domain.ChenkProduct;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Repository("WmsAsnChenkInventoryMapper")
@Mapper
public interface ChenkInventoryMapper {

    /*判断仓库表中是否有该数据*/
    public int countChenkInventory(String itemSkuCode);
    /*插入新的数据到仓库库存表*/
    public boolean insertChenkInventory(ChenkProduct product);
    /*更新仓库库存表*/
    public boolean updateChenkInventory(ChenkProduct product);
}
