package com.chenk.wmsasn.domain;

public class Package {
    private String packCode;
    private String packLogisticsProviderCode;
    private String packShippingOrderNo;
    private String packWeight;
    private String packNetWeight;
    private String packGrossWeight;
    private String packVolume;
    private String packLength;
    private String packWidth;
    private String packHeight;
    private String warehouseCode;
    private PackProducts packProducts;

    public String getPackCode() {
        return packCode;
    }

    public void setPackCode(String packCode) {
        this.packCode = packCode;
    }

    public String getPackLogisticsProviderCode() {
        return packLogisticsProviderCode;
    }

    public void setPackLogisticsProviderCode(String packLogisticsProviderCode) {
        this.packLogisticsProviderCode = packLogisticsProviderCode;
    }

    public String getPackShippingOrderNo() {
        return packShippingOrderNo;
    }

    public void setPackShippingOrderNo(String packShippingOrderNo) {
        this.packShippingOrderNo = packShippingOrderNo;
    }

    public String getPackWeight() {
        return packWeight;
    }

    public void setPackWeight(String packWeight) {
        this.packWeight = packWeight;
    }

    public String getPackNetWeight() {
        return packNetWeight;
    }

    public void setPackNetWeight(String packNetWeight) {
        this.packNetWeight = packNetWeight;
    }

    public String getPackGrossWeight() {
        return packGrossWeight;
    }

    public void setPackGrossWeight(String packGrossWeight) {
        this.packGrossWeight = packGrossWeight;
    }

    public String getPackVolume() {
        return packVolume;
    }

    public void setPackVolume(String packVolume) {
        this.packVolume = packVolume;
    }

    public String getPackLength() {
        return packLength;
    }

    public void setPackLength(String packLength) {
        this.packLength = packLength;
    }

    public String getPackWidth() {
        return packWidth;
    }

    public void setPackWidth(String packWidth) {
        this.packWidth = packWidth;
    }

    public String getPackHeight() {
        return packHeight;
    }

    public void setPackHeight(String packHeight) {
        this.packHeight = packHeight;
    }

    public String getWarehouseCode() {
        return warehouseCode;
    }

    public void setWarehouseCode(String warehouseCode) {
        this.warehouseCode = warehouseCode;
    }

    public PackProducts getPackProducts() {
        return packProducts;
    }

    public void setPackProducts(PackProducts packProducts) {
        this.packProducts = packProducts;
    }

    @Override
    public String toString() {
        return "Package{" +
                "packCode='" + packCode + '\'' +
                ", packLogisticsProviderCode='" + packLogisticsProviderCode + '\'' +
                ", packShippingOrderNo='" + packShippingOrderNo + '\'' +
                ", packWeight='" + packWeight + '\'' +
                ", packNetWeight='" + packNetWeight + '\'' +
                ", packGrossWeight='" + packGrossWeight + '\'' +
                ", packVolume='" + packVolume + '\'' +
                ", packLength='" + packLength + '\'' +
                ", packWidth='" + packWidth + '\'' +
                ", packHeight='" + packHeight + '\'' +
                ", warehouseCode='" + warehouseCode + '\'' +
                ", packProducts=" + packProducts +
                '}';
    }
}
