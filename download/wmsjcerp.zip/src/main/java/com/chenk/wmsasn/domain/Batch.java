package com.chenk.wmsasn.domain;

public class Batch {
    private String itemSkuCode;
    private String fixStatusCode;
    private String productionDate;
    private String expiryDate;
    private String lotAtt01;
    private String lotAtt02;
    private String lotAtt03;
    private String lotAtt04;
    private String lotAtt05;
    private String lotAtt06;
    private String packCode;
    private String uomCode;
    private int quantity;

    public String getItemSkuCode() {
        return itemSkuCode;
    }

    public void setItemSkuCode(String itemSkuCode) {
        this.itemSkuCode = itemSkuCode;
    }

    public String getFixStatusCode() {
        return fixStatusCode;
    }

    public void setFixStatusCode(String fixStatusCode) {
        this.fixStatusCode = fixStatusCode;
    }

    public String getProductionDate() {
        return productionDate;
    }

    public void setProductionDate(String productionDate) {
        this.productionDate = productionDate;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getLotAtt01() {
        return lotAtt01;
    }

    public void setLotAtt01(String lotAtt01) {
        this.lotAtt01 = lotAtt01;
    }

    public String getLotAtt02() {
        return lotAtt02;
    }

    public void setLotAtt02(String lotAtt02) {
        this.lotAtt02 = lotAtt02;
    }

    public String getLotAtt03() {
        return lotAtt03;
    }

    public void setLotAtt03(String lotAtt03) {
        this.lotAtt03 = lotAtt03;
    }

    public String getLotAtt04() {
        return lotAtt04;
    }

    public void setLotAtt04(String lotAtt04) {
        this.lotAtt04 = lotAtt04;
    }

    public String getLotAtt05() {
        return lotAtt05;
    }

    public void setLotAtt05(String lotAtt05) {
        this.lotAtt05 = lotAtt05;
    }

    public String getLotAtt06() {
        return lotAtt06;
    }

    public void setLotAtt06(String lotAtt06) {
        this.lotAtt06 = lotAtt06;
    }

    public String getPackCode() {
        return packCode;
    }

    public void setPackCode(String packCode) {
        this.packCode = packCode;
    }

    public String getUomCode() {
        return uomCode;
    }

    public void setUomCode(String uomCode) {
        this.uomCode = uomCode;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "Batch{" +
                "itemSkuCode='" + itemSkuCode + '\'' +
                ", fixStatusCode='" + fixStatusCode + '\'' +
                ", productionDate='" + productionDate + '\'' +
                ", expiryDate='" + expiryDate + '\'' +
                ", lotAtt01='" + lotAtt01 + '\'' +
                ", lotAtt02='" + lotAtt02 + '\'' +
                ", lotAtt03='" + lotAtt03 + '\'' +
                ", lotAtt04='" + lotAtt04 + '\'' +
                ", lotAtt05='" + lotAtt05 + '\'' +
                ", lotAtt06='" + lotAtt06 + '\'' +
                ", packCode='" + packCode + '\'' +
                ", uomCode='" + uomCode + '\'' +
                ", quantity=" + quantity +
                '}';
    }
}
