package com.chenk.wmsasn.domain;


/*
* Chenk的仓库表信息
*
* */
public class ChenkInventory {
    /*
    * 仓库编号
    * */
    private String warehouseCode;
    /*
    * 产品编号
    * */
    private String itemSkuCode;

    /*
     * 最小库存数
     * */
    private int minQuantity;

    /*
    * 当前库存数量
    * */
    private int currentQuantity;
    /*
    * 累计入库数量
    * */
    private int cumulativeQuantity;

    /*
     * 单价
     * */
    private double unitPrice;

    /*
    * 总价
    * */
    private double totalPrice;


    public String getWarehouseCode() {
        return warehouseCode;
    }

    public void setWarehouseCode(String warehouseCode) {
        this.warehouseCode = warehouseCode;
    }

    public String getItemSkuCode() {
        return itemSkuCode;
    }

    public void setItemSkuCode(String itemSkuCode) {
        this.itemSkuCode = itemSkuCode;
    }

    public int getCurrentQuantity() {
        return currentQuantity;
    }

    public void setCurrentQuantity(int currentQuantity) {
        this.currentQuantity = currentQuantity;
    }

    public int getCumulativeQuantity() {
        return cumulativeQuantity;
    }

    public void setCumulativeQuantity(int cumulativeQuantity) {
        this.cumulativeQuantity = cumulativeQuantity;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public int getMinQuantity() {
        return minQuantity;
    }

    public void setMinQuantity(int minQuantity) {
        this.minQuantity = minQuantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    @Override
    public String toString() {
        return "ChenkInventory{" +
                "warehouseCode='" + warehouseCode + '\'' +
                ", itemSkuCode='" + itemSkuCode + '\'' +
                ", minQuantity=" + minQuantity +
                ", currentQuantity=" + currentQuantity +
                ", cumulativeQuantity=" + cumulativeQuantity +
                ", unitPrice=" + unitPrice +
                ", totalPrice=" + totalPrice +
                '}';
    }
}
