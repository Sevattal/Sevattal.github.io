package com.chenk.wmsasn.domain;

import java.util.List;

public class Packages {
    private List<Package>  ChenkPackage;

    public List<Package> getChenkPackage() {
        return ChenkPackage;
    }

    public void setChenkPackage(List<Package> chenkPackage) {
        ChenkPackage = chenkPackage;
    }
}
