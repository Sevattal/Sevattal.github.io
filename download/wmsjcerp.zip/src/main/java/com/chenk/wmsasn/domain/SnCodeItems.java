package com.chenk.wmsasn.domain;

import java.util.List;

public class SnCodeItems {
    private List<SnCodeItem> snCodeItem;

    public List<SnCodeItem> getSnCodeItem() {
        return snCodeItem;
    }

    public void setSnCodeItem(List<SnCodeItem> snCodeItem) {
        this.snCodeItem = snCodeItem;
    }
}
