package com.chenk.wmsasn.mapper;


import com.chenk.wmsasn.domain.ChenkProduct;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("WmsAsnChenkProductMappr")
@Mapper
public interface ChenkProductMapper {

    /*查询订单明细表数据*/
    public List<ChenkProduct> selectChenkProduct(String orderCode);
}
