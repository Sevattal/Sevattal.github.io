package com.chenk.wmsasn.domain;


public class StatusPush {

    private String customerCode;
    private String warehouseCode;
    private String orderCode;
    private String asnStatus;
    private String refOrderCode;
    private String extOrderType;
    private String logisticsProviderCode;
    private String shippingOrderNo;
    private String remark;
    private String receiveTime;
    private String checkStartTime;
    private String checkEndTime;
    private String orderTime;
    private boolean udfFlag;
    private String udf1;
    private String udf2;
    private String udf3;
    private String udf4;
    private String udf5;
    private String udf6;
    private String udf7;
    private String udf8;
    private double totalVolume;
    private double totalWeight;
    private double totalNetWeight;
    private boolean wmsCreatedFlag;
    private String skuItem;

    /*
    * 一个入库状态信息同步过来，有多个产品信息，一个产品信息又对应了多个Batch信息
    * 一个入库状态信息同步过来，对应多个SnCodeItems，即多个唯一码
    * 从上述可知，要建立表的话需要建立以下数据表
    * WmsAsnStatusPush表，Product表，SnCodeItem表，SnCode表
    * WmsAsnStatusPush与Product 关联表
    * Batch与Product 关联表Batch
    * SnCodeItem与WmsAsnStatusPush 关联表
    * SnCode与SnCodeItem 关联表
    * 从上述可知，要想实现全部功能总共需要用到9张表
    *
    * 若只要完成best官方给出得必填参数，只需要建立以下数据表
    * WmsAsnStatusPush表，Product表，WmsAsnStatusPush与Product 关联表
    * WmsAsnStatusPush表为：入库单状态信息推送信息表，为主表
    * Product表为：入库单得产品信息表，同步时最好独立创建这个表，那么总共需要创建3张表。
    * 但是上述说的Batch，SnCodeItem等表得PoJo类要创建完毕以接收数据
    * */

    private Products products;
    private SnCodeItems snCodeItems;


    /*
    * 接口文档上方request中没有写该参数，但是在下面的json数据格式中有显示
    * */
    private  Recipient recipient;
    private Packages packages;

    public Packages getPackages() {
        return packages;
    }

    public void setPackages(Packages packages) {
        this.packages = packages;
    }

    public Products getProducts() {
        return products;
    }

    public void setProducts(Products products) {
        this.products = products;
    }

    public String getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }

    public String getWarehouseCode() {
        return warehouseCode;
    }

    public void setWarehouseCode(String warehouseCode) {
        this.warehouseCode = warehouseCode;
    }

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    public String getAsnStatus() {
        return asnStatus;
    }

    public void setAsnStatus(String asnStatus) {
        this.asnStatus = asnStatus;
    }

    public String getRefOrderCode() {
        return refOrderCode;
    }

    public void setRefOrderCode(String refOrderCode) {
        this.refOrderCode = refOrderCode;
    }

    public String getExtOrderType() {
        return extOrderType;
    }

    public void setExtOrderType(String extOrderType) {
        this.extOrderType = extOrderType;
    }

    public String getLogisticsProviderCode() {
        return logisticsProviderCode;
    }

    public void setLogisticsProviderCode(String logisticsProviderCode) {
        this.logisticsProviderCode = logisticsProviderCode;
    }

    public String getShippingOrderNo() {
        return shippingOrderNo;
    }

    public void setShippingOrderNo(String shippingOrderNo) {
        this.shippingOrderNo = shippingOrderNo;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getReceiveTime() {
        return receiveTime;
    }

    public void setReceiveTime(String receiveTime) {
        this.receiveTime = receiveTime;
    }

    public String getCheckStartTime() {
        return checkStartTime;
    }

    public void setCheckStartTime(String checkStartTime) {
        this.checkStartTime = checkStartTime;
    }

    public String getCheckEndTime() {
        return checkEndTime;
    }

    public void setCheckEndTime(String checkEndTime) {
        this.checkEndTime = checkEndTime;
    }

    public String getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(String orderTime) {
        this.orderTime = orderTime;
    }

    public boolean isUdfFlag() {
        return udfFlag;
    }

    public void setUdfFlag(boolean udfFlag) {
        this.udfFlag = udfFlag;
    }

    public String getUdf1() {
        return udf1;
    }

    public void setUdf1(String udf1) {
        this.udf1 = udf1;
    }

    public String getUdf2() {
        return udf2;
    }

    public void setUdf2(String udf2) {
        this.udf2 = udf2;
    }

    public String getUdf3() {
        return udf3;
    }

    public void setUdf3(String udf3) {
        this.udf3 = udf3;
    }

    public String getUdf4() {
        return udf4;
    }

    public void setUdf4(String udf4) {
        this.udf4 = udf4;
    }

    public String getUdf5() {
        return udf5;
    }

    public void setUdf5(String udf5) {
        this.udf5 = udf5;
    }

    public String getUdf6() {
        return udf6;
    }

    public void setUdf6(String udf6) {
        this.udf6 = udf6;
    }

    public String getUdf7() {
        return udf7;
    }

    public void setUdf7(String udf7) {
        this.udf7 = udf7;
    }

    public String getUdf8() {
        return udf8;
    }

    public void setUdf8(String udf8) {
        this.udf8 = udf8;
    }

    public double getTotalVolume() {
        return totalVolume;
    }

    public void setTotalVolume(double totalVolume) {
        this.totalVolume = totalVolume;
    }

    public double getTotalWeight() {
        return totalWeight;
    }

    public void setTotalWeight(double totalWeight) {
        this.totalWeight = totalWeight;
    }

    public double getTotalNetWeight() {
        return totalNetWeight;
    }

    public void setTotalNetWeight(double totalNetWeight) {
        this.totalNetWeight = totalNetWeight;
    }

    public boolean isWmsCreatedFlag() {
        return wmsCreatedFlag;
    }

    public void setWmsCreatedFlag(boolean wmsCreatedFlag) {
        this.wmsCreatedFlag = wmsCreatedFlag;
    }

    public String getSkuItem() {
        return skuItem;
    }

    public void setSkuItem(String skuItem) {
        this.skuItem = skuItem;
    }

    public SnCodeItems getSnCodeItems() {
        return snCodeItems;
    }

    public void setSnCodeItems(SnCodeItems snCodeItems) {
        this.snCodeItems = snCodeItems;
    }

    public Recipient getRecipient() {
        return recipient;
    }

    public void setRecipient(Recipient recipient) {
        this.recipient = recipient;
    }

    @Override
    public String toString() {
        return "StatusPush{" +
                "customerCode='" + customerCode + '\'' +
                ", warehouseCode='" + warehouseCode + '\'' +
                ", orderCode='" + orderCode + '\'' +
                ", asnStatus='" + asnStatus + '\'' +
                ", refOrderCode='" + refOrderCode + '\'' +
                ", extOrderType='" + extOrderType + '\'' +
                ", logisticsProviderCode='" + logisticsProviderCode + '\'' +
                ", shippingOrderNo='" + shippingOrderNo + '\'' +
                ", remark='" + remark + '\'' +
                ", receiveTime='" + receiveTime + '\'' +
                ", checkStartTime='" + checkStartTime + '\'' +
                ", checkEndTime='" + checkEndTime + '\'' +
                ", orderTime='" + orderTime + '\'' +
                ", udfFlag=" + udfFlag +
                ", udf1='" + udf1 + '\'' +
                ", udf2='" + udf2 + '\'' +
                ", udf3='" + udf3 + '\'' +
                ", udf4='" + udf4 + '\'' +
                ", udf5='" + udf5 + '\'' +
                ", udf6='" + udf6 + '\'' +
                ", udf7='" + udf7 + '\'' +
                ", udf8='" + udf8 + '\'' +
                ", totalVolume=" + totalVolume +
                ", totalWeight=" + totalWeight +
                ", totalNetWeight=" + totalNetWeight +
                ", wmsCreatedFlag=" + wmsCreatedFlag +
                ", skuItem='" + skuItem + '\'' +
                ", products=" + products +
                ", snCodeItems=" + snCodeItems +
                '}';
    }
}
