package com.chenk.wmsasn.service;


import com.alibaba.fastjson.JSONObject;

public interface WmsAsnService {

    /*
    * 对单一订单的同步
    * */
    public boolean wmsasn(JSONObject jsonObject);

}
