package com.chenk.wmsasn.domain;


/*
* 该类用于接收入Chenk本地入库单明细表所需数据
* 按道理应该是使用ProductMapper去更新订单数量数据
* 但是best给的Product表中没有已入库数量和未入库数量这些字段
* 所以该实体类是为了获取未入库数量信息
* 而创建的实体类
*
* */
public class ChenkProduct {
    // orderCode 订单号
    private String orderCode;
    // itemCode 产品号
    private String itemSkuCode;
    // minQuantity 最小库存数
    private int minQuantity;
    // sumQuantity 全部数量
    private int sumQuantity;
    // loadedQuantity 已入库数量
    private int loadedQuantity;
    // unloadedQuantity 未入库数量
    private int unloadedQuantity;
    //unitPrice单价
    private double unitPrice;


    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    public String getItemSkuCode() {
        return itemSkuCode;
    }

    public void setItemSkuCode(String itemSkuCode) {
        this.itemSkuCode = itemSkuCode;
    }

    public int getSumQuantity() {
        return sumQuantity;
    }

    public void setSumQuantity(int sumQuantity) {
        this.sumQuantity = sumQuantity;
    }

    public int getLoadedQuantity() {
        return loadedQuantity;
    }

    public void setLoadedQuantity(int loadedQuantity) {
        this.loadedQuantity = loadedQuantity;
    }

    public int getUnloadedQuantity() {
        return unloadedQuantity;
    }

    public void setUnloadedQuantity(int unloadedQuantity) {
        this.unloadedQuantity = unloadedQuantity;
    }

    public int getMinQuantity() {
        return minQuantity;
    }

    public void setMinQuantity(int minQuantity) {
        this.minQuantity = minQuantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    @Override
    public String toString() {
        return "ChenkProduct{" +
                "orderCode='" + orderCode + '\'' +
                ", itemSkuCode='" + itemSkuCode + '\'' +
                ", minQuantity=" + minQuantity +
                ", sumQuantity=" + sumQuantity +
                ", loadedQuantity=" + loadedQuantity +
                ", unloadedQuantity=" + unloadedQuantity +
                ", unitPrice=" + unitPrice +
                '}';
    }
}
