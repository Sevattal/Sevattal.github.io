package com.chenk.wmsasn.service.Impl;

import com.alibaba.fastjson.JSONObject;
import com.chenk.wmsasn.domain.ChenkProduct;
import com.chenk.wmsasn.mapper.ChenkInventoryMapper;
import com.chenk.wmsasn.mapper.ChenkProductMapper;
import com.chenk.wmsasn.service.WmsAsnService;
import com.chenk.wmsasn.domain.StatusPush;
import com.chenk.wmsasn.mapper.StatusPushMapper;
import com.chenk.wmsasn.mapper.ProductMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service
public class WmsAsnServiceImpl implements WmsAsnService {

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private StatusPushMapper statusPushMapper;

    @Autowired
    private ChenkProductMapper chenkProductMapper;

    @Autowired
    private ChenkInventoryMapper chenkInventoryMapper;


    private StatusPush statusPush = new StatusPush();
    private List<ChenkProduct> list;

    private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(WmsAsnServiceImpl.class);


    @Transactional
    @Override
    public boolean wmsasn(JSONObject jsonObject) {
        /*
         * 打印获取的参数即状态信息
         * */
        LOGGER.info("WmsAsn Service update Start");
        LOGGER.info("WmsAsn Service Get JsonObject: " + jsonObject.toJSONString());

        /*
         * 将JSONObject对象转换成statusPush对象
         * */
        LOGGER.info("WmsAsn LocalJsonObject Change statusPush Object Start");
        statusPush=jsonObject.toJavaObject(StatusPush.class);
        LOGGER.info("WmsAsn LocalJsonObject Change statusPush Object Ok");

        /*
         * 若订单不存在直接返回false
         * */
        if (statusPushMapper.countStatusPush(statusPush.getOrderCode()) != 1){

            LOGGER.info(statusPush.getOrderCode()+"订单不存在");
            return false;
        }

        /*
        * 判断传入的AsnStatus入库状态是否是所需的FULFILLED
        * 即全部入库
        * 若传入的不是FULFILLED,则不允许同步
        * */
        if (statusPush.getAsnStatus().equalsIgnoreCase("FULFILLED")){

            LOGGER.info("传入的数据为: FULFILLED 参数正确,允许同步");
        }else {

            LOGGER.info("传入的数据不为: FULFILLED 不允许同步");
            return false;
        }

        /*
         * 更新入库单表状态信息，即入库数量
         * */
        statusPushMapper.updateStatusPush(statusPush.getOrderCode());

        /*
         * 获取入库明细表信息
         *
         * */
        list = chenkProductMapper.selectChenkProduct(statusPush.getOrderCode());

        /*
         * 判断订单中的产品在库存中是否存在,
         * 存在则更新库存表
         * 不存在则插入库存表
         *
         * */
        LOGGER.info("开始更新处理仓库库存信息");
        for (int i =0; i<list.size();i++){

            if (chenkInventoryMapper.countChenkInventory(list.get(i).getItemSkuCode()) == 1){

                LOGGER.info("ItemCode: "+list.get(i).getItemSkuCode()+" ,更新仓库库存表");
                chenkInventoryMapper.updateChenkInventory(list.get(i));

            }else if (chenkInventoryMapper.countChenkInventory(list.get(i).getItemSkuCode()) == 0){

                LOGGER.info("ItemCode: "+list.get(i).getItemSkuCode()+" ,新增仓库库存表");
                chenkInventoryMapper.insertChenkInventory(list.get(i));

            }else {

                LOGGER.info("库存表的数据有错误,同一仓库拥有相同的产品信息\n" + "即:一个仓库对应多个相同产品信息");

            }
        }

        /*
         * 更新入库单明细表状态信息，即入库数量
         * */
        LOGGER.info("开始更新出入库明细表同步状态信息");
        productMapper.updateProduct(statusPush.getOrderCode());
        LOGGER.info("订单完全入库,入库信息同步完成");
        return true;

    }
}
