package com.chenk.wmsasn.domain;

public class SnCodeItem {
    private String skuCode;
    private String providerCode;
    private String providerFrom;
    private String providerName;
    private SnCodeList snCodeList;

    public String getSkuCode() {
        return skuCode;
    }

    public void setSkuCode(String skuCode) {
        this.skuCode = skuCode;
    }

    public String getProviderCode() {
        return providerCode;
    }

    public void setProviderCode(String providerCode) {
        this.providerCode = providerCode;
    }

    public String getProviderFrom() {
        return providerFrom;
    }

    public void setProviderFrom(String providerFrom) {
        this.providerFrom = providerFrom;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public SnCodeList getSnCodeList() {
        return snCodeList;
    }

    public void setSnCodeList(SnCodeList snCodeList) {
        this.snCodeList = snCodeList;
    }

    @Override
    public String toString() {
        return "SnCodeItems{" +
                "skuCode='" + skuCode + '\'' +
                ", providerCode='" + providerCode + '\'' +
                ", providerFrom='" + providerFrom + '\'' +
                ", providerName='" + providerName + '\'' +
                ", snCodeList=" + snCodeList +
                '}';
    }
}
