package com.chenk.wmsasn.domain;

public class PackProduct {
    private String packCode;
    private String packSkuCode;
    private String packProviderCode;
    private String packQuantity;

    public String getPackCode() {
        return packCode;
    }

    public void setPackCode(String packCode) {
        this.packCode = packCode;
    }

    public String getPackSkuCode() {
        return packSkuCode;
    }

    public void setPackSkuCode(String packSkuCode) {
        this.packSkuCode = packSkuCode;
    }

    public String getPackProviderCode() {
        return packProviderCode;
    }

    public void setPackProviderCode(String packProviderCode) {
        this.packProviderCode = packProviderCode;
    }

    public String getPackQuantity() {
        return packQuantity;
    }

    public void setPackQuantity(String packQuantity) {
        this.packQuantity = packQuantity;
    }

    @Override
    public String toString() {
        return "PackProduct{" +
                "packCode='" + packCode + '\'' +
                ", packSkuCode='" + packSkuCode + '\'' +
                ", packProviderCode='" + packProviderCode + '\'' +
                ", packQuantity='" + packQuantity + '\'' +
                '}';
    }
}
