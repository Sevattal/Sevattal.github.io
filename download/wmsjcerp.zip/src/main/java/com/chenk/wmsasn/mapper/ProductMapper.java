package com.chenk.wmsasn.mapper;


import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;


@Mapper
@Repository("WmsAsnProductMapper")
public interface ProductMapper {
    //更新出入库子表信息
    public boolean updateProduct(String orderCode);
}
