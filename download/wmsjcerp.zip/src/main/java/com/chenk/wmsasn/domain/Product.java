package com.chenk.wmsasn.domain;

public class Product {
    private String itemSkuCode;
    private String providerCode;
    private String providerFrom;
    private String providerName;
    private int itemQuantity;
    private int normalQuantity;
    private double decimalNormalQty;
    private int defectiveQuantity;
    private double decimalDefectiveQty;
    private double averageWeight;
    private double averageGrossWeight;
    private double averageNetWeight;
    private double averageVolume;
    private double averageLength;
    private double averageWidth;
    private double averageHeight;
    private long lineNo;
    private String barCode;
    private String skuUdf1;
    private String skuUdf2;
    private String skuUdf3;
    private String skuUdf4;
    private String skuUdf5;
    private String skuUdf6;
    private String skuUdf7;
    private String skuUdf8;
    private String udf1;
    private String udf2;
    private String udf3;
    private String udf4;
    private String udf5;
    private String udf6;
    private String udf7;
    private String udf8;
    private Batchs batchs;

    public String getItemSkuCode() {
        return itemSkuCode;
    }

    public void setItemSkuCode(String itemSkuCode) {
        this.itemSkuCode = itemSkuCode;
    }

    public String getProviderCode() {
        return providerCode;
    }

    public void setProviderCode(String providerCode) {
        this.providerCode = providerCode;
    }

    public String getProviderFrom() {
        return providerFrom;
    }

    public void setProviderFrom(String providerFrom) {
        this.providerFrom = providerFrom;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public int getItemQuantity() {
        return itemQuantity;
    }

    public void setItemQuantity(int itemQuantity) {
        this.itemQuantity = itemQuantity;
    }

    public int getNormalQuantity() {
        return normalQuantity;
    }

    public void setNormalQuantity(int normalQuantity) {
        this.normalQuantity = normalQuantity;
    }

    public double getDecimalNormalQty() {
        return decimalNormalQty;
    }

    public void setDecimalNormalQty(double decimalNormalQty) {
        this.decimalNormalQty = decimalNormalQty;
    }

    public int getDefectiveQuantity() {
        return defectiveQuantity;
    }

    public void setDefectiveQuantity(int defectiveQuantity) {
        this.defectiveQuantity = defectiveQuantity;
    }

    public double getDecimalDefectiveQty() {
        return decimalDefectiveQty;
    }

    public void setDecimalDefectiveQty(double decimalDefectiveQty) {
        this.decimalDefectiveQty = decimalDefectiveQty;
    }

    public double getAverageWeight() {
        return averageWeight;
    }

    public void setAverageWeight(double averageWeight) {
        this.averageWeight = averageWeight;
    }

    public double getAverageGrossWeight() {
        return averageGrossWeight;
    }

    public void setAverageGrossWeight(double averageGrossWeight) {
        this.averageGrossWeight = averageGrossWeight;
    }

    public double getAverageNetWeight() {
        return averageNetWeight;
    }

    public void setAverageNetWeight(double averageNetWeight) {
        this.averageNetWeight = averageNetWeight;
    }

    public double getAverageVolume() {
        return averageVolume;
    }

    public void setAverageVolume(double averageVolume) {
        this.averageVolume = averageVolume;
    }

    public double getAverageLength() {
        return averageLength;
    }

    public void setAverageLength(double averageLength) {
        this.averageLength = averageLength;
    }

    public double getAverageWidth() {
        return averageWidth;
    }

    public void setAverageWidth(double averageWidth) {
        this.averageWidth = averageWidth;
    }

    public double getAverageHeight() {
        return averageHeight;
    }

    public void setAverageHeight(double averageHeight) {
        this.averageHeight = averageHeight;
    }

    public long getLineNo() {
        return lineNo;
    }

    public void setLineNo(long lineNo) {
        this.lineNo = lineNo;
    }

    public String getBarCode() {
        return barCode;
    }

    public void setBarCode(String barCode) {
        this.barCode = barCode;
    }

    public String getSkuUdf1() {
        return skuUdf1;
    }

    public void setSkuUdf1(String skuUdf1) {
        this.skuUdf1 = skuUdf1;
    }

    public String getSkuUdf2() {
        return skuUdf2;
    }

    public void setSkuUdf2(String skuUdf2) {
        this.skuUdf2 = skuUdf2;
    }

    public String getSkuUdf3() {
        return skuUdf3;
    }

    public void setSkuUdf3(String skuUdf3) {
        this.skuUdf3 = skuUdf3;
    }

    public String getSkuUdf4() {
        return skuUdf4;
    }

    public void setSkuUdf4(String skuUdf4) {
        this.skuUdf4 = skuUdf4;
    }

    public String getSkuUdf5() {
        return skuUdf5;
    }

    public void setSkuUdf5(String skuUdf5) {
        this.skuUdf5 = skuUdf5;
    }

    public String getSkuUdf6() {
        return skuUdf6;
    }

    public void setSkuUdf6(String skuUdf6) {
        this.skuUdf6 = skuUdf6;
    }

    public String getSkuUdf7() {
        return skuUdf7;
    }

    public void setSkuUdf7(String skuUdf7) {
        this.skuUdf7 = skuUdf7;
    }

    public String getSkuUdf8() {
        return skuUdf8;
    }

    public void setSkuUdf8(String skuUdf8) {
        this.skuUdf8 = skuUdf8;
    }

    public String getUdf1() {
        return udf1;
    }

    public void setUdf1(String udf1) {
        this.udf1 = udf1;
    }

    public String getUdf2() {
        return udf2;
    }

    public void setUdf2(String udf2) {
        this.udf2 = udf2;
    }

    public String getUdf3() {
        return udf3;
    }

    public void setUdf3(String udf3) {
        this.udf3 = udf3;
    }

    public String getUdf4() {
        return udf4;
    }

    public void setUdf4(String udf4) {
        this.udf4 = udf4;
    }

    public String getUdf5() {
        return udf5;
    }

    public void setUdf5(String udf5) {
        this.udf5 = udf5;
    }

    public String getUdf6() {
        return udf6;
    }

    public void setUdf6(String udf6) {
        this.udf6 = udf6;
    }

    public String getUdf7() {
        return udf7;
    }

    public void setUdf7(String udf7) {
        this.udf7 = udf7;
    }

    public String getUdf8() {
        return udf8;
    }

    public void setUdf8(String udf8) {
        this.udf8 = udf8;
    }

    public Batchs getBatchs() {
        return batchs;
    }

    public void setBatchs(Batchs batchs) {
        this.batchs = batchs;
    }

    @Override
    public String toString() {
        return "Product{" +
                "itemSkuCode='" + itemSkuCode + '\'' +
                ", providerCode='" + providerCode + '\'' +
                ", providerFrom='" + providerFrom + '\'' +
                ", providerName='" + providerName + '\'' +
                ", itemQuantity=" + itemQuantity +
                ", normalQuantity=" + normalQuantity +
                ", decimalNormalQty=" + decimalNormalQty +
                ", defectiveQuantity=" + defectiveQuantity +
                ", decimalDefectiveQty=" + decimalDefectiveQty +
                ", averageWeight=" + averageWeight +
                ", averageGrossWeight=" + averageGrossWeight +
                ", averageNetWeight=" + averageNetWeight +
                ", averageVolume=" + averageVolume +
                ", averageLength=" + averageLength +
                ", averageWidth=" + averageWidth +
                ", averageHeight=" + averageHeight +
                ", lineNo=" + lineNo +
                ", barCode='" + barCode + '\'' +
                ", skuUdf1='" + skuUdf1 + '\'' +
                ", skuUdf2='" + skuUdf2 + '\'' +
                ", skuUdf3='" + skuUdf3 + '\'' +
                ", skuUdf4='" + skuUdf4 + '\'' +
                ", skuUdf5='" + skuUdf5 + '\'' +
                ", skuUdf6='" + skuUdf6 + '\'' +
                ", skuUdf7='" + skuUdf7 + '\'' +
                ", skuUdf8='" + skuUdf8 + '\'' +
                ", udf1='" + udf1 + '\'' +
                ", udf2='" + udf2 + '\'' +
                ", udf3='" + udf3 + '\'' +
                ", udf4='" + udf4 + '\'' +
                ", udf5='" + udf5 + '\'' +
                ", udf6='" + udf6 + '\'' +
                ", udf7='" + udf7 + '\'' +
                ", udf8='" + udf8 + '\'' +
                ", batchs=" + batchs +
                '}';
    }
}