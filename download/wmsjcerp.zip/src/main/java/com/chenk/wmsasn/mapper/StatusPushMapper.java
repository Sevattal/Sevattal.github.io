package com.chenk.wmsasn.mapper;

import com.chenk.wmsasn.domain.StatusPush;
import jdk.net.SocketFlow;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository("WmsAsnStatusPushMapper")
public interface StatusPushMapper {

    //更新StatusPush数据
    public boolean updateStatusPush(String orderCode);

    //查询StatusPush单条数据
    public StatusPush selectStatusPush(String orderCode);

    //查询数据是否存在
    public int countStatusPush(String orderCode);



}
