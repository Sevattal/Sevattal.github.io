package com.chenk.wmsasn.domain;

import java.util.List;

public class PackProducts {
    private List<PackProduct> packProduct;

    public List<PackProduct> getPackProduct() {
        return packProduct;
    }

    public void setPackProduct(List<PackProduct> packProduct) {
        this.packProduct = packProduct;
    }
}
