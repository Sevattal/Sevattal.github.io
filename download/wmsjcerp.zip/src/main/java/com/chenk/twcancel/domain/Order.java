package com.chenk.twcancel.domain;

public class Order {
    //订单号
    private String orderCode;
    //订单类型
    private String orderType;

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderCode='" + orderCode + '\'' +
                ", orderType='" + orderType + '\'' +
                '}';
    }
}
