package com.chenk.twcancel.mapper;


import com.chenk.twcancel.domain.Order;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("TwCancelOrderMapper")
@Mapper
public interface OrderMapper {

    /*
    * 获取订单信息
    * */
    public Order selectOrder(String orderCode);

    /*
    * 判断订单是否存在
    * */
    public int countOrder(String orderCode);

}
