package com.chenk.twcancel.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.chenk.twcancel.service.TwCancelService;
import com.chenk.util.ChenkJsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TwCancelController {


    /*
    * 加载服务层
    * */
    @Autowired
    private TwCancelService twCancelService;

    /*
    * 日志配置
    * */
    private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(TwCancelController.class);

    @RequestMapping("twcancel")
    public String twcancel(@RequestBody String orderCode){
        /*
        * TwCancel开始信息
        * */
        LOGGER.info("TwCancel Controller Start");


        /*
         * 将Json数据转换成字符串
         * */
        JSONObject jsonObject = JSON.parseObject(orderCode);
        LOGGER.info("orderCode: " + jsonObject.get("orderCode"));
        String order = jsonObject.getString("orderCode");

        /*
        * 判断orderCode 是否为空
        * */
        if (order.isEmpty() || order.equalsIgnoreCase("")){
            LOGGER.info("orderCode: " + order + "为空,不允许同步");
            return ChenkJsonUtil.getJsonResultFalse().toJSONString();
        }

        LOGGER.info("OrderCode: " + order);



        /*
        * 开始处理Service层
        * */
        boolean flag = twCancelService.twcancel(order);

        /*
        * 返回同步信息结果
        *
        * */
        if (flag == true){
            LOGGER.info("orderCode: " + order +" is Cancel Successfully");
            return ChenkJsonUtil.getJsonResultTrue().toJSONString();

        }else {
            LOGGER.info("orderCode: " + order +" is Cancel Failure");
            return ChenkJsonUtil.getJsonResultFalse().toJSONString();
        }
    }
}
