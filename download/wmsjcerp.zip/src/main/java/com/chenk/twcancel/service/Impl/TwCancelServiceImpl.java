package com.chenk.twcancel.service.Impl;

import com.best.javaSdk.twCancelNotiry.request.TwCancelNotiryReq;
import com.best.javaSdk.twCancelNotiry.response.TwCancelNotiryRsp;
import com.chenk.twcancel.domain.Order;
import com.chenk.twcancel.mapper.OrderMapper;
import com.chenk.twcancel.service.TwCancelService;
import com.chenk.util.BestPramUtil;
import com.chenk.util.ClientUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TwCancelServiceImpl  implements TwCancelService {


    @Autowired
    private OrderMapper orderMapper;


    private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(TwCancelServiceImpl.class);
    private ClientUtil clientUtil = new ClientUtil();
    private TwCancelNotiryReq Req = new TwCancelNotiryReq();
    private TwCancelNotiryRsp Rsp = new TwCancelNotiryRsp();
    private Order order;

    @Override
    public boolean twcancel(String orderCode) {


        /*
        * 提示Service层开始执行
        * */
        LOGGER.info("TwCancel Service  Start");

        /*
        * 判断本地是否存在该订单号
        * */
        if (orderMapper.countOrder(orderCode) != 1){
            LOGGER.info("OrderCode: " + orderCode +" 订单信息不存在");
            return false;
        }

        /*
        * 传入取消订单必填值
        * */
        LOGGER.info("Req 传百世接口取消订单必传值");
        Req.setCustomerCode(BestPramUtil.getCustomerCode());
        Req.setOrderCode(orderCode);

        /*
         * 获取订单是出库还是入库
         * */
        order= orderMapper.selectOrder(orderCode);
        LOGGER.info("获取订单所需基本信息: "+order.toString());

        if (order.getOrderType().indexOf("入库") != -1) {

            LOGGER.info("OrderCode: " + orderCode + " 该订单为入库订单" );
            Req.setOperationTypeCode("ASN");

        }else if (order.getOrderType().indexOf("出库") != -1){

            LOGGER.info("OrderCode: " + orderCode + " 该订单为出库订单");
            Req.setOperationTypeCode("WDO");

        }

        /*
        * 打印Req结果信息
        * */
        LOGGER.info("打印取消订单Req传参信息: "+Req.toString());

        /*
        * 发送取消订单请求
        * */
        Rsp = clientUtil.getClient().executed(Req);

        /*
        * 返回取消订单结果
        * */
        if (Rsp.getResult() == true){

            LOGGER.info("取消订单成功");
            LOGGER.info("TwCancel Service Successfully");
            return true;

        }else {

            LOGGER.info("取消订单失败");
            LOGGER.info("Rsp Note: "+ Rsp.getNote());
            LOGGER.info("Rsp ErrorDescription: "+Rsp.getErrorDescription());
            return  false;

        }
    }
}
