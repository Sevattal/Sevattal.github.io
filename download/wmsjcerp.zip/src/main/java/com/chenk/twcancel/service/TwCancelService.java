package com.chenk.twcancel.service;

public interface TwCancelService {

    public boolean twcancel(String orderCode);
}
