package com;


import com.chenk.util.SignatureUtil;

public class testEQ {
    public static void main(String[] args) {
        SignatureUtil signatureUtil = new SignatureUtil();
        String serviceType = "WMS_ASN_STATUS_PUSH";
        String sign = "82744adfbba4d63a830c7060abf03762";
        String bizData ="{\"customerCode\":\"WT2010143054\",\"warehouseCode\":\"BEST_WH\",\"warehouseAddressCode\":null,\"orderCode\":\"RK20201023005\",\"refOrderCode\":null,\"operationTypeCode\":\"ASN\",\"asnStatus\":\"FULFILLED\",\"logisticsProviderCode\":null,\"shippingOrderNo\":null,\"receiveTime\":\"2015-07-16T13:47:22\",\"checkStartTime\":\"2015-07-16T15:11:37\",\"checkEndTime\":\"2015-07-16T15:38:13\",\"isMulFeedBack\":null,\"isFinish\":null,\"note\":null,\"extOrderType\":null,\"wmsCreatedFlag\":null,\"orderTime\":null,\"udfFlag\":null,\"udf1\":null,\"udf2\":null,\"udf3\":null,\"udf4\":null,\"udf5\":null,\"udf6\":null,\"udf7\":null,\"udf8\":null,\"totalVolume\":null,\"totalWeight\":null,\"totalNetWeight\":null,\"skuItem\":\"1\",\"products\":{\"product\":[{\"itemSkuCode\":\"YLQX-0026\",\"providerCode\":null,\"providerFrom\":null,\"providerName\":null,\"itemQuantity\":100,\"normalQuantity\":100,\"defectiveQuantity\":0,\"decimalNormalQty\":null,\"decimalDefectiveQty\":null,\"averageWeight\":0.0,\"averageGrossWeight\":0.0,\"averageNetWeight\":0.0,\"averageVolume\":0.0,\"averageLength\":0.0,\"averageWidth\":0.0,\"averageHeight\":0.0,\"lineNo\":1,\"barCode\":\"CA653001R9\",\"skuUdf1\":\"82212275.\",\"skuUdf2\":\"ţŌ\",\"skuUdf3\":null,\"skuUdf4\":null,\"skuUdf5\":null,\"skuUdf6\":null,\"skuUdf7\":null,\"skuUdf8\":null,\"udf1\":null,\"udf2\":null,\"udf3\":null,\"udf4\":null,\"udf5\":null,\"udf6\":null,\"udf7\":null,\"udf8\":null,\"itemNote\":null,\"batchs\":{\"batch\":[{\"fixStatusCode\":\"Y\",\"productionDate\":\"2017-10-10\",\"uomCode\":\"EA\",\"quantity\":100}]},\"feedBackIndex\":null}]},\"snCodeItems\":null}";
        String partnerID ="3875";

        if (signatureUtil.isReal(serviceType,sign,bizData,partnerID)){
            System.out.println("true");
        }else {
            System.out.println("false");
        }



    }

}
