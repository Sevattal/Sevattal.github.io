package com;

import java.util.ArrayList;
import java.util.List;

public class testList {

    public static void main(String[] args) {
        List<Integer> lists = new ArrayList<Integer>();
        List subList;

        for (int i=1;i<=100;i++){
            lists.add(i);
        }
        System.out.println(lists);
        /*
        * 经过测试，前一个值是开始数据地址，但是这个地址的值不取值
        * */
        //subList=lists.subList(98,100);
        subList=lists.subList(1,2);
        System.out.println(subList);



    }
}
