package com;

public class testFor {

    public static void main(String[] args) {
        for (int i =0 ; i< 200;){
            System.out.println(i+"----"+i+100);
            System.out.println(i);
        }

    }
}
