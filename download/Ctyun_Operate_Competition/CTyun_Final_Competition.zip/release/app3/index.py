import requests
import boto3
from boto3.session import Session
import json 
import logging
import random
import os 
import base64
'''
需求：
1.写入文件
下载连接，再传输到s3上,保留6个最新版本

2.读取文件
从对象存储总读取s3的对象存储，从6个最新版本中随机选择一个版本发送给客户端
'''


# 从环境变量中读取配置信息
access_key = os.environ.get("ak", "341XVE9FEI4C8GAAAAAA")
secret_key = os.environ.get("sk", "ugC1nZpuaqBvXJygiiroFwLwOHmkL9z000000000")
endpoint = os.environ.get("endpoint", "https://jiangsu-10.zos.ctyun.cn")
s3_bucket = os.environ.get("bucket", "BUCKET_NAME")
s3_object_key_prefix = os.environ.get("key_prefix","ad_data/")

session = Session(access_key, secret_key)
client = session.client("s3", endpoint_url=endpoint)

def write_ad_data(file_body, file_meta):
    max_slot = 6
    target_solt = 0
    # s3对象存储桶内只保留最新的6个广告数据, 如果来新的数据，就替换掉旧的
    resp = client.list_objects(Bucket=s3_bucket, Prefix=s3_object_key_prefix+"data/")
    if resp.get("Contents") is None:
        # 如果找不到存储桶，
        target_solt = 0
    elif len(resp["Contents"]) < max_slot:
        target_solt = len(resp['Contents'])
    else:
        oldest_solt = 0
        contents = resp["Contents"]
        for i in range(len(contents)):
            print(i, contents[i]["LastModified"])
            if contents[i]["LastModified"] < contents[oldest_solt]["LastModified"]:
                oldest_solt = i 
        target_solt = oldest_solt
    resp2 = client.put_object(Bucket=s3_bucket, Key="%sdata/%d"%(s3_object_key_prefix, target_solt), Body=file_body)
    resp2 = client.put_object(Bucket=s3_bucket, Key="%smeta/%d"%(s3_object_key_prefix, target_solt), Body=file_meta)

def get_ad_data():
    # 随机返回对象存储桶中的1个广告数据
    resp = client.list_objects(Bucket=s3_bucket, Prefix=s3_object_key_prefix+"data/")
    contents = resp.get('Contents')
    if contents is None:
        raise BaseException("没有找到广告文件")
    data_key = contents[random.randint(0,len(contents)-1)]['Key']
    meta_key = "%smeta/%s"%(s3_object_key_prefix, data_key.split("/")[-1])
    resp = client.get_object(Bucket=s3_bucket, Key=data_key)
    data_obj = resp["Body"].read()
    resp = client.get_object(Bucket=s3_bucket, Key=meta_key)
    meta_obj = resp["Body"].read()
    return data_obj, meta_obj


def handler(environ, start_response):
    print("...Successfully entered user http function...")

    # 输出日志信息
    logging.getLogger().info("using default user logger...")

    # 测试 evnrion 是否被正确解析
    for key, value in environ.items():
        if key.startswith('HTTP_'):
            # 对请求的信息进行处理
            pass
    
    path = environ['PATH_INFO']
    method = environ['REQUEST_METHOD']
    body = environ["wsgi.input"].read()
    print("path: ", path)
    print("method: ", method)
    print("body: ", body)
    '''
    读取文件
    请求方式：GET
    请求路径：/api/get
    '''
    if path == "/api/get" and method == "GET":
        try:
            data, meta = get_ad_data()
        except Exception as e:
            status = '500 Internal Server Error'
            start_response(status, [('Content-type', 'text/plain')])
            print("读取广告数据失败：", e)
            return ["读取广告数据失败"]
        start_response("200 OK", [('Content-type', 'text/plain')])
        return [json.dumps({
            "data": base64.b64encode(data).decode("utf8"),
            "meta": base64.b64encode(meta).decode("utf8")
        })]
    '''
    写入文件
    请求方式：POST
    请求路径：/api/upload
    Body格式：json 示例如下
    {
        "data": "some data here",
        "meta": "some metadata here"
    }
    '''
    if path == "/api/upload" and method == "POST":
        try:
            body = json.loads(body)
            data = body['data']
            meta = body['meta']
        except:
            status = '400 Bad request'
            response_headers = [('Content-type', 'text/plain')]
            start_response(status, response_headers)
            return ["bad request"]
        try:
            write_ad_data(data, meta)
        except Exception as e :
            status = '500 Internal Server Error'
            response_headers = [('Content-type', 'text/plain')]
            start_response(status, response_headers)
            print("保存文件失败")
            return ["保存文件失败"]
        start_response("200 OK", [('Content-type', 'text/plain')])
        return ["success"]
        
    # 返回响应
    status = '404 Not Fount'
    response_headers = [('Content-type', 'text/plain')]
    start_response(status, response_headers)
    return ["not found"]

