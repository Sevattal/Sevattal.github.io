package com.sevattal.springcloud.controller;

import com.sevattal.springcloud.entities.CommonResult;
import com.sevattal.springcloud.entities.Payment;
import com.sevattal.springcloud.service.PaymentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Slf4j
public class PaymentController {

    @Resource
    private PaymentService paymentService;

    /*
    * 读取application 中 server.port的端口配置
    * */
    @Value("${server.port}")
    private String serverPort;
    /*
    * 服务发现
    * */
    @Resource
    private DiscoveryClient discoveryClient;

    @PostMapping(value = "/payment/create")
    public CommonResult<Payment> create(@RequestBody Payment payment){
        int result = paymentService.create(payment);
        log.info("****插入结果：" + result);

        if (result > 0) {
            return new CommonResult(200,"插入数据库成功, server-port: " + serverPort,result);
        }else {
            return new CommonResult(444,"插入数据库失败",result);
        }
    }

    @GetMapping(value = "/payment/get/{id}")
    public CommonResult getPaymentById(@PathVariable("id") Long id){
        Payment payment = paymentService.getPaymentById(id);
        log.info("****插入结果： " + payment);

        if (payment != null) {
            return new CommonResult(200,"查询成功, server-port: " + serverPort,payment);
        }else {
            return new CommonResult(444,"查询失败, 查询ID:" + id ,null);
        }
    }

    @GetMapping(value = "/payment/discovery")
    public Object discovery() {
        /*
        * 获得微服务的名称
        *
        * */
        List<String> services = discoveryClient.getServices();
        for (String element: services){
            log.info("*******element: " + element);
        }
        /*
        * 获得某一微服务下的所有实例实例名
        * */
        List<ServiceInstance> instances = discoveryClient.getInstances("CLOUD-PROVIDER-SERVICE");
        for (ServiceInstance instance: instances){
            log.info(instance.getServiceId() + "\t" + instance.getHost() + "\t" + instance.getPort() + "\t" +instance.getUri());
        }
        return this.discoveryClient;
    }
}
