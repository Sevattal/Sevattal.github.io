read -p "Please input the system ip:" ip
filename=$ip.txt
while read -r line
do
 echo "--------------------"$line"--------------------">>$filename
 eval $line>>$filename
done <Command.txt
