'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://localhost:8222"',
}
